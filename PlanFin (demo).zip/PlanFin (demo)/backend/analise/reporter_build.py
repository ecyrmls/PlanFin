# -*- coding: utf-8 -*-
from __future__ import annotations
import pandas as pd
from typing import Dict
from .config import SELIC_ANUAL, IPCA_ANUAL, POUPANCA_ANUAL

def _compound(rate_annual: float, years: int) -> list[float]:
    vals = [1.0]
    for _ in range(years):
        vals.append(vals[-1] * (1.0 + rate_annual))
    return vals

def _compound_money(rate_annual: float, years: int, initial: float, yearly_contrib: float) -> list[float]:
    vals = [float(initial) + float(yearly_contrib)]
    for _ in range(years):
        vals.append(vals[-1] * (1.0 + rate_annual) + float(yearly_contrib))
    return vals

def _to_float(x):
    try:
        return float(str(x).replace(",", ".").strip())
    except Exception:
        return 0.0

def _walk_items(d):
    if isinstance(d, dict):
        for k, v in d.items():
            yield k, v
            for kk, vv in _walk_items(v):
                yield f"{k}.{kk}", vv
    elif isinstance(d, list):
        for i, v in enumerate(d):
            for kk, vv in _walk_items(v):
                yield f"[{i}].{kk}", vv

def _read_number(respostas: dict, keys: list[str]) -> float:
    norm = []
    for k in keys:
        nk = k.lower()
        for a,b in ("áàãâ","a"), ("éê","e"), ("í","i"), ("óôõ","o"), ("ú","u"), ("ç","c"):
            for ch in a: nk = nk.replace(ch, b)
        norm.append(nk.replace(" ", "").replace("_", ""))
    best = 0.0
    for k, v in _walk_items(respostas):
        lk = str(k).lower()
        for a,b in ("áàãâ","a"), ("éê","e"), ("í","i"), ("ó","o"), ("ô","o"), ("õ","o"), ("ú","u"), ("ç","c"):
            for ch in a: lk = lk.replace(ch, b)
        lk = lk.replace(" ", "").replace("_","")
        for p in norm:
            if p in lk:
                val = _to_float(v)
                if val != 0.0: return val
                best = max(best, val)
    return best

def _aporte_anual(respostas: dict) -> float:
    # aporteAnual = (rendaMensal - (gastosFixos + gastosVariaveis)) * 12
    def _num(res, keys):
        try:
            s = next((res[k] for k in res if k.lower().replace("_","")==keys.lower().replace("_","")), None)
        except StopIteration:
            s = None
        return _to_float(s)
    # mais robusto: vasculha aninhado
    renda_mensal = _read_number(respostas, ["rendaMensal","renda_mensal","renda mensal"])
    gastos_fixos = _read_number(respostas, ["gastosFixos","gastos_fixos","gastos fixos"])
    gastos_var   = _read_number(respostas, ["gastosVariaveis","gastosVariáveis","gastos_variaveis","gastosMensais","gastos_mensais","gastos mensais"])
    return max(0.0, renda_mensal - (gastos_fixos + gastos_var)) * 12.0

def _capital_inicial(respostas: dict) -> float:
    # some TODOS os campos que começam com "valor" ou terminam com "_valor"
    total = 0.0
    for k, v in _walk_items(respostas):
        base = str(k).lower().strip().replace(" ","").replace("_","")
        if base.startswith("valor") or base.endswith("valor"):
            total += _to_float(v)
    return total

def _avg_portfolio_rate(selection: pd.DataFrame) -> float:
    if selection is None or selection.empty or "rent_12m" not in selection.columns or "weight" not in selection.columns:
        return 0.0
    sel = selection[["rent_12m","weight"]].dropna()
    if sel.empty: return 0.0
    return float((sel["rent_12m"] * sel["weight"]).sum())

def build_payload(selection: pd.DataFrame, bucket_weights: Dict[str,float], respostas: dict) -> Dict:
    assets = []
    if selection is not None and not selection.empty:
        for _, r in selection.iterrows():
            assets.append({
                "label": r.get("nome_exibir", r.get("ticker", r.get("nome",""))),
                "class": r.get("bucket"),
                "weight": float(r.get("weight", 0) or 0),
                "rent_12m": float(r.get("rent_12m", 0) or 0),
                "rentabilidade_liquida": float(r.get("rentabilidade_liquida")) if pd.notna(r.get("rentabilidade_liquida", None)) else None
            })

    by_bucket = [{"bucket": b, "weight": float(w)} for b, w in bucket_weights.items()]

    years = list(range(0, 51))
    media = max(0.0, _avg_portfolio_rate(selection))
    carteira_idx = _compound(media, years[-1])
    selic_idx    = _compound(SELIC_ANUAL, years[-1])
    ipca_idx     = _compound(IPCA_ANUAL, years[-1])
    poup_idx     = _compound(POUPANCA_ANUAL, years[-1])

    capital_inicial = _capital_inicial(respostas)
    aporte_anual = _aporte_anual(respostas)

    carteira_rs = _compound_money(media, years[-1], capital_inicial, aporte_anual)
    selic_rs    = _compound_money(SELIC_ANUAL, years[-1], capital_inicial, aporte_anual)
    ipca_rs     = _compound_money(IPCA_ANUAL, years[-1], capital_inicial, aporte_anual)
    poup_rs     = _compound_money(POUPANCA_ANUAL, years[-1], capital_inicial, aporte_anual)

    return {
        "byAsset": assets,
        "byBucket": by_bucket,
        "lifeLine": {
            "years": years,
            "percent": {"carteira": carteira_idx, "selic": selic_idx, "ipca": ipca_idx, "poupanca": poup_idx},
            "reais": {
                "carteira": carteira_rs, "selic": selic_rs, "ipca": ipca_rs, "poupanca": poup_rs,
                "capital_inicial": capital_inicial, "aporte_anual": aporte_anual
            }
        }
    }
