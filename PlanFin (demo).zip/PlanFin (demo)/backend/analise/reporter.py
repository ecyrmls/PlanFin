# -*- coding: utf-8 -*-
from __future__ import annotations
import argparse, os, json, sys
from pathlib import Path
from typing import List, Optional
import pandas as pd

if __package__ in (None, ""):
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from backend.analise.config import Config, PROFILES
    from backend.analise.utils import load_json, load_comp_set
    from backend.analise.etapa1_fundos import agrupar_fundos
    from backend.analise.etapa1_agregador import filtrar_agregador
    from backend.analise.etapa1_yahoo import filtrar_yahoo
    from backend.analise.etapa2_select import select_assets_simplificado
    from backend.analise.reporter_build import build_payload
else:
    from .config import Config, PROFILES
    from .utils import load_json, load_comp_set
    from .etapa1_fundos import agrupar_fundos
    from .etapa1_agregador import filtrar_agregador
    from .etapa1_yahoo import filtrar_yahoo
    from .etapa2_select import select_assets_simplificado
    from .reporter_build import build_payload

def parse_args(argv=None):
    ap = argparse.ArgumentParser(description="PlanFin Análise Runner (Simplificado)")
    ap.add_argument("--answers", required=True)
    ap.add_argument("--inputs-manifest", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--profile", default=None)
    return ap.parse_args(argv)

def _ensure_stage1(respostas, srcs, cfg, stage_dir: Path):
    stage_dir.mkdir(parents=True, exist_ok=True)
    # Fundos (Fonte 1 e Fonte 2)
    fundos_out = stage_dir / "fundos_agrupados.csv"
    if not fundos_out.exists():
        fundos_csvs: List[str] = [p for p in [srcs.get("fonte_1"), srcs.get("fonte_2")] if p]
        df_fundos = agrupar_fundos(fundos_csvs, out_csv=str(fundos_out))
    else:
        df_fundos = pd.read_csv(fundos_out)
    # Agregador RF (títulos)
    agregador_out = stage_dir / "agregador_filtrado.csv"
    if not agregador_out.exists():
        agregador_csv: Optional[str] = srcs.get("agregador_rf") or None
        df_agregador = filtrar_agregador(agregador_csv, respostas, out_csv=str(agregador_out)) if agregador_csv else None
    else:
        df_agregador = pd.read_csv(agregador_out)
    # Yahoo
    yahoo_out = stage_dir / "yahoo_filtrado.csv"
    if not yahoo_out.exists():
        parts = []
        yf_files = srcs.get("yfinance_files") or []
        yf_single = srcs.get("yfinance") or None
        if isinstance(yf_files, list) and yf_files:
            for p in yf_files:
                dfp = filtrar_yahoo(p, cfg.comp_ifix, cfg.comp_ibov, cfg.comp_ibrx50, cfg.comp_idiv, out_csv=None)
                if dfp is not None and not dfp.empty:
                    parts.append(dfp)
        elif yf_single:
            dfp = filtrar_yahoo(yf_single, cfg.comp_ifix, cfg.comp_ibov, cfg.comp_ibrx50, cfg.comp_idiv, out_csv=None)
            if dfp is not None and not dfp.empty:
                parts.append(dfp)
        df_yahoo = pd.concat(parts, ignore_index=True) if parts else pd.DataFrame(columns=["fonte","ticker","rent_12m","volatilidade","beta"])
        if "ticker" in df_yahoo.columns and not df_yahoo.empty:
            df_yahoo = df_yahoo.drop_duplicates(subset=["ticker"], keep="first")
        df_yahoo.to_csv(yahoo_out, index=False, encoding="utf-8")
    else:
        df_yahoo = pd.read_csv(yahoo_out)
    return df_fundos, df_agregador, df_yahoo

def main(argv=None) -> int:
    args = parse_args(argv)
    raw_json = load_json(str(Path(args.answers))) if Path(args.answers).exists() else {}
    manifest = load_json(str(Path(args.inputs_manifest))) if Path(args.inputs_manifest).exists() else {}
    out_json = Path(args.out)

    # O JSON pode ter estrutura {"session_id": ..., "respostas": {...}} ou ser direto
    if "respostas" in raw_json and isinstance(raw_json.get("respostas"), dict):
        respostas = raw_json["respostas"]
    else:
        respostas = raw_json

    srcs = manifest.get("sources", {})
    
    # Extrai perfil do questionário (respostas) ou usa argumento/default
    profile_from_answers = (respostas.get("perfilInvestidor") or "").strip().lower()
    profile = (args.profile or profile_from_answers or "moderado").strip().lower()
    if profile not in PROFILES: profile = "moderado"

    env = os.environ
    cfg = Config(session_id = manifest.get("session_id","session"),
                 profile    = profile,
                 fundos_csvs = [],
                 agregador_csv = None,
                 yahoo_csv = None,
                 comp_ifix = env.get("PLANFIN_COMP_IFIX"),
                 comp_ibov = env.get("PLANFIN_COMP_IBOV"),
                 comp_ibrx50 = env.get("PLANFIN_COMP_IBRX50"),
                 comp_idiv = env.get("PLANFIN_COMP_IDIV"))

    stage_dir = out_json.parent / "stage1"
    df_fundos, df_agregador, df_yahoo = _ensure_stage1(respostas, srcs, cfg, stage_dir)

    # período para regra do Agregador RF
    periodo = next((v for k,v in (respostas or {}).items() if str(k).lower()=="periodosimulacaomeses"), None)
    set_ifix = load_comp_set(cfg.comp_ifix) if cfg.comp_ifix else set()

    bucket_weights = PROFILES[cfg.profile]
    selection = select_assets_simplificado(cfg.profile, bucket_weights, df_fundos, df_agregador, df_yahoo, set_ifix=set_ifix, periodo_meses=periodo)

    # DEBUG: salvar selecionados.csv
    try:
        if selection is not None and not selection.empty:
            sel_csv = out_json.parent / "selecionados.csv"
            cols = [c for c in selection.columns if c not in ("ticker_base","beta_num")]
            selection[cols].to_csv(sel_csv, index=False, encoding="utf-8")
    except Exception as e:
        print(f"[WARN] falha ao salvar selecionados.csv: {e}", file=sys.stderr)

    payload = build_payload(selection, bucket_weights, respostas=respostas)
    out_json.parent.mkdir(parents=True, exist_ok=True)
    out_json.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[OK] JSON final salvo em {out_json}")
    return 0

if __name__ == "__main__":
    sys.exit(main())
