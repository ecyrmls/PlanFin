from __future__ import annotations
import os, json
import pandas as pd
from .config import Config, PROFILES
from .utils import load_json, ensure_dir, save_csv, load_comp_set
from .etapa1_fundos import agrupar_fundos
from .etapa1_agregador import filtrar_agregador
from .etapa1_yahoo import filtrar_yahoo
from .etapa2_select import select_assets
from .reporter import build_payload

CONFIG = Config(
    session_id = "SEU_SESSION_ID_AQUI",
    profile    = "moderado",
    fundos_csvs = [],
    agregador_csv = None,
    yahoo_csv = None,
    comp_ifix = None,
    comp_ibov = None,
    comp_ibrx50 = None,
    comp_idiv = None,
)

def run(cfg: Config):
    answers_path = os.path.join(cfg.respostas_dir, f"{cfg.session_id}.json")
    respostas = load_json(answers_path) if os.path.exists(answers_path) else {}

    ensure_dir(cfg.out_stage1)
    fundos_out = os.path.join(cfg.out_stage1, "fundos_agrupados.csv")
    agregador_out = os.path.join(cfg.out_stage1, "agregador_filtrado.csv")
    yahoo_out  = os.path.join(cfg.out_stage1, "yahoo_filtrado.csv")

    df_fundos = agrupar_fundos(cfg.fundos_csvs, fundos_out)

    df_agregador = None
    if cfg.agregador_csv:
        df_agregador = filtrar_agregador(cfg.agregador_csv, respostas, agregador_out)

    df_yahoo = None
    if cfg.yahoo_csv:
        df_yahoo = filtrar_yahoo(cfg.yahoo_csv, cfg.comp_ifix, cfg.comp_ibov, cfg.comp_ibrx50, cfg.comp_idiv, yahoo_out)

    set_ifix = load_comp_set(cfg.comp_ifix)

    ensure_dir(cfg.out_stage2)
    bucket_weights = PROFILES[cfg.profile]

    periodo = None
    for k, v in respostas.items():
        if str(k).lower() == "periodosimulacaomeses":
            periodo = v
            break
    use_agregador_rf = (isinstance(periodo, (int,float)) and periodo > 12)
    df_agregador_rf = df_agregador if use_agregador_rf else None

    selection = select_assets(cfg.profile, bucket_weights, df_fundos, df_agregador_rf, df_yahoo, set_ifix=set_ifix)
    save_csv(selection, os.path.join(cfg.out_stage2, "selecionados.csv"))

    payload = build_payload(selection, bucket_weights)
    out_json = os.path.join(cfg.out_stage2, "resultado.json")
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)

    print("[OK] Etapa 1 e 2 concluídas.")
    print(" - Fundos agrupados   :", fundos_out)
    print(" - Agregador filtrado :", agregador_out if cfg.agregador_csv else "(não gerado)")
    print(" - Yahoo filtrado     :", yahoo_out if cfg.yahoo_csv else "(não gerado)")
    print(" - Selecionados       :", os.path.join(cfg.out_stage2, "selecionados.csv"))
    print(" - JSON final         :", out_json)

if __name__ == "__main__":
    run(CONFIG)
