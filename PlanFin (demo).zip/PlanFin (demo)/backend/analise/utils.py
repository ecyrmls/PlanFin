# -*- coding: utf-8 -*-
from __future__ import annotations
import os, json
import pandas as pd

def try_read_csv(path: str|None) -> pd.DataFrame|None:
    if not path: return None
    for sep in (",",";","\t","|"):
        try:
            df = pd.read_csv(path, sep=sep)
            if df is not None:
                return df
        except Exception:
            continue
    return None

def pct_to_decimal_series(s: pd.Series) -> pd.Series:
    import numpy as np
    if s is None: return s
    def conv(x):
        if x is None: return np.nan
        try:
            xs = str(x).strip().replace('%','').replace(',','.')
            if xs == '': return np.nan
            val = float(xs)
            return val/100.0 if val > 3.0 else val
        except Exception:
            return np.nan
    return s.apply(conv)

def save_csv(df, path: str): df.to_csv(path, index=False, encoding='utf-8')

def load_json(path: str) -> dict:
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)

def load_comp_set(path: str|None):
    """Lê um CSV de componentes (ex.: ifix.csv) e retorna um set de tickers UPPER().
    Aceita separadores variados e tenta detectar a coluna certa (ticker/symbol/codigo);
    Se não achar, usa a primeira coluna.
    """
    if not path: return set()
    df = try_read_csv(path)
    if df is None or df.empty: return set()
    df.columns = [str(c).strip().lower() for c in df.columns]
    cand = None
    for c in ("ticker","symbol","simbolo","símbolo","codigo","código","asset","nome","name"):
        if c in df.columns: cand = c; break
    if cand is None:
        cand = df.columns[0]
    col = df[cand].astype(str).str.upper().str.strip()
    # remove vazios/"NAN"
    col = col[col.notna() & (col.str.len()>0) & (col != "NAN")]
    return set(col.tolist())
