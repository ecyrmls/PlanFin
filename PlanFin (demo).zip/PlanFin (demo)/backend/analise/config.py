# -*- coding: utf-8 -*-
from __future__ import annotations

SELIC_ANUAL = 0.15
IPCA_ANUAL = 0.0513
POUPANCA_ANUAL = 0.0617

PROFILES = {
    "conservador": {"RF": 0.70, "MM": 0.15, "ACOES": 0.15},
    "moderado":    {"RF": 0.40, "MM": 0.20, "ACOES": 0.40},
    "arrojado":    {"RF": 0.10, "MM": 0.20, "ACOES": 0.70},
}
class Config:
    def __init__(self, session_id, profile, fundos_csvs, agregador_csv, yahoo_csv,
                 comp_ifix, comp_ibov, comp_ibrx50, comp_idiv):
        self.session_id=session_id; self.profile=profile
        self.fundos_csvs=fundos_csvs; self.agregador_csv=agregador_csv; self.yahoo_csv=yahoo_csv
        self.comp_ifix=comp_ifix; self.comp_ibov=comp_ibov; self.comp_ibrx50=comp_ibrx50; self.comp_idiv=comp_idiv