# -*- coding: utf-8 -*-
from __future__ import annotations
import pandas as pd
import re
import sys
from typing import Dict, Optional, Set

def _ticker_base(x: str) -> str:
    if x is None: return ""
    u = str(x).upper().strip()
    return u.split(".", 1)[0]

def _set_base(names: Set[str]|None) -> Set[str]:
    return set(_ticker_base(n) for n in (names or set()))

def _is_benchmark_like(t: str) -> bool:
    if t is None: return False
    u = re.sub(r"\s+", "", str(t).upper().strip())
    if u.startswith("^"): u = u[1:]
    if u.endswith("*"):  u = u[:-1]
    return u in {"IBOV","IBX50","IFIX","IDIV","ISMARTDIV","IBOVLOW","BDRX"}

def _drop_benchmarks(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or df.empty: return df
    for col in ("ticker","nome","nome_exibir","label"):
        if col in df.columns:
            df = df[~df[col].map(_is_benchmark_like)]
    return df

def _risk_ok(profile: str, risco_val: str) -> bool:
    if not risco_val: return True
    r = str(risco_val).strip().lower()
    low = {"baixo","baixa","low"}
    mid = {"medio","médio","media","média","medium"}
    if profile == "conservador": return r in low
    if profile == "moderado":    return (r in low) or (r in mid)
    return True  # arrojado

def _pick_top(df: pd.DataFrame, n: int, key: str, secondary: Optional[str]=None) -> pd.DataFrame:
    if df is None or df.empty: return df
    df = df.copy()
    if secondary and secondary in df.columns:
        return df.sort_values([key, secondary], ascending=[False, False], na_position="last").head(n).copy()
    return df.sort_values(key, ascending=False, na_position="last").head(n).copy()

def select_assets_simplificado(
    profile: str,
    bucket_weights: Dict[str,float],
    df_fundos: pd.DataFrame,
    df_agregador: Optional[pd.DataFrame],
    df_yahoo: Optional[pd.DataFrame],
    set_ifix: Optional[Set[str]] = None,
    periodo_meses: Optional[float] = None
) -> pd.DataFrame:
    picks = []

    # normalizações
    if df_yahoo is not None and not df_yahoo.empty:
        df_yahoo = df_yahoo.copy()
        df_yahoo["ticker"] = df_yahoo["ticker"].astype(str).str.upper()
        beta_col = next((c for c in df_yahoo.columns if "beta" in str(c).lower()), None)
        if beta_col and "beta" not in df_yahoo.columns:
            df_yahoo["beta"] = pd.to_numeric(df_yahoo[beta_col], errors="coerce")
        df_yahoo = _drop_benchmarks(df_yahoo)

    if df_fundos is not None and not df_fundos.empty:
        df_fundos = df_fundos.copy()
        if "categoria" not in df_fundos.columns and "class" in df_fundos.columns:
            df_fundos["categoria"] = df_fundos["class"]

    for bucket, w in bucket_weights.items():
        if w <= 0: 
            continue

        # ===== RF =====
        if bucket == "RF":
            U = None
            use_agregador = (isinstance(periodo_meses, (int, float)) and periodo_meses > 12) and (df_agregador is not None and not df_agregador.empty)
            if use_agregador:
                U = df_agregador.copy()
                U["nome_exibir"] = U.get("nome", U.get("produto", "RF"))
                U["bucket"] = "RF"
                U["fonte_tipo"] = "AGREGADOR_RF"
                key, sec = "rent_12m", None
            else:
                if df_fundos is None or df_fundos.empty:
                    continue
                cand = df_fundos.copy()
                rx_rf = r"(renda\s*fixa|rf\b|cr[eé]dito|credito|cdi\b|d[ií]vida|debentur|debêntur|soberano|pos[- ]?fixado|p[oó]s[- ]?fixado|prefixado|firf|curto\s*prazo|longo\s*prazo)"
                mask = cand["categoria"].astype(str).str.contains(rx_rf, case=False, regex=True, na=False)
                cand = cand[mask]
                if "risco" in cand.columns:
                    cand = cand[cand["risco"].apply(lambda x: _risk_ok(profile, x))]
                if cand.empty:
                    continue
                cand["nome_exibir"] = cand["nome"]
                cand["bucket"] = "RF"
                cand["fonte_tipo"] = "FUND"
                U = cand
                key, sec = ("rent_12m" if "rent_12m" in U.columns else "rent_ano"), ("rent_ano" if "rent_ano" in U.columns else None)

            if U is None or U.empty or key not in U.columns:
                continue
            S = _pick_top(U, 3, key, sec)
            if S.empty: 
                continue
            S["weight_in_bucket"] = 1.0 / len(S)
            S["bucket_weight"] = w
            S["weight"] = S["weight_in_bucket"] * S["bucket_weight"]
            picks.append(S)
            continue

        # ===== MM =====
        if bucket == "MM":
            if df_fundos is None or df_fundos.empty:
                continue
            mm = df_fundos[df_fundos["categoria"].astype(str).str.contains("multimerc", case=False, na=False)].copy()
            if "risco" in mm.columns:
                mm = mm[mm["risco"].apply(lambda x: _risk_ok(profile, x))]
            if mm.empty: 
                continue
            mm["nome_exibir"] = mm["nome"]
            mm["bucket"] = "MM"
            mm["fonte_tipo"] = "FUND"
            S = _pick_top(mm, 3, "rent_12m", "rent_ano" if "rent_ano" in mm.columns else None)
            if S.empty: 
                continue
            S["weight_in_bucket"] = 1.0 / len(S)
            S["bucket_weight"] = w
            S["weight"] = S["weight_in_bucket"] * S["bucket_weight"]
            picks.append(S)
            continue

        # ===== ACOES =====
        if bucket == "ACOES":
            universe = []
            # fundos de ações
            if df_fundos is not None and not df_fundos.empty:
                fa = df_fundos[df_fundos["categoria"].astype(str).str.contains("aç|aco", case=False, na=False, regex=True)].copy()
                if "risco" in fa.columns:
                    fa = fa[fa["risco"].apply(lambda x: _risk_ok(profile, x))]
                if not fa.empty:
                    fa["nome_exibir"] = fa["nome"]
                    fa["bucket"] = "ACOES"
                    fa["fonte_tipo"] = "FUND"
                    universe.append(fa)
            # ações do Yahoo (benchmarks já limpos)
            if df_yahoo is not None and not df_yahoo.empty:
                ya = df_yahoo.copy()
                ya["nome_exibir"] = ya["ticker"]
                ya["bucket"] = "ACOES"
                ya["fonte_tipo"] = "YF"
                universe.append(ya)
            if not universe:
                continue
            U = pd.concat(universe, ignore_index=True) if len(universe) > 1 else universe[0]
            U = _drop_benchmarks(U)
            key = "rent_12m" if "rent_12m" in U.columns else None
            if key is None or U.empty:
                continue
            if profile == "conservador" and "volatilidade" in U.columns:
                U = U.sort_values(["rent_12m","volatilidade"], ascending=[False, True], na_position="last")
                S = U.head(3).copy()
            else:
                S = _pick_top(U, 3, key, "rent_ano" if "rent_ano" in U.columns else None)
            if S.empty:
                continue
            S["weight_in_bucket"] = 1.0 / len(S)
            S["bucket_weight"] = w
            S["weight"] = S["weight_in_bucket"] * S["bucket_weight"]
            picks.append(S)
            continue

    if not picks:
        return pd.DataFrame(columns=["nome_exibir","bucket","rent_12m","weight"])
    return pd.concat(picks, ignore_index=True)

# Alias para compatibilidade
select_assets = select_assets_simplificado
