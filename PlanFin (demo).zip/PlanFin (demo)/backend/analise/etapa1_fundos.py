# -*- coding: utf-8 -*-
from __future__ import annotations
import os, pandas as pd
from typing import List
from .utils import try_read_csv, pct_to_decimal_series, save_csv

def agrupar_fundos(fundos_csvs: List[str], out_csv: str|None = None):
    frames = []
    for p in fundos_csvs:
        df = try_read_csv(p)
        if df is None or df.empty: continue
        df.columns = [c.lower() for c in df.columns]
        nome_col = "nome" if "nome" in df.columns else ("fundname" if "fundname" in df.columns else ("name" if "name" in df.columns else None))
        cat_col = "categoria" if "categoria" in df.columns else ("class" if "class" in df.columns else None)
        risco_col = next((c for c in ["risco","risk","risk_label","riskname","risk_name","classe_risco","classe de risco"] if c in df.columns), None)
        df["rent_ano"] = pct_to_decimal_series(df["rent_ano"]) if "rent_ano" in df.columns else None
        df["rent_12m"] = pct_to_decimal_series(df["rent_12m"]) if "rent_12m" in df.columns else None
        fonte = p.split("/")[-1].split("\\")[-1].split(".")[0].upper()
        frames.append(pd.DataFrame({
            "fonte": fonte,
            "nome": df[nome_col] if nome_col else "",
            "categoria": df[cat_col] if cat_col else "",
            "risco": df[risco_col] if risco_col else "",
            "rent_ano": df["rent_ano"],
            "rent_12m": df["rent_12m"],
        }))
    res = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame(columns=["fonte","nome","categoria","risco","rent_ano","rent_12m"])
    if out_csv and os.path.isdir(os.path.dirname(out_csv)): save_csv(res, out_csv)
    return res
