# -*- coding: utf-8 -*-
from __future__ import annotations
import os, re
import pandas as pd
from .utils import try_read_csv, pct_to_decimal_series, save_csv

def _is_benchmark_like(t: str) -> bool:
    if t is None:
        return False
    u = re.sub(r"\s+", "", str(t).upper().strip())
    if u.startswith("^"):
        u = u[1:]
    if u.endswith("*"):
        u = u[:-1]
    base = {"IBOV","IBX50","IFIX","IDIV","ISMARTDIV","IBOVLOW","BDRX"}
    return u in base

def filtrar_yahoo(
    yahoo_csv: str,
    comp_ifix: str | None,
    comp_ibov: str | None,
    comp_ibrx50: str | None,
    comp_idiv: str | None,
    out_csv: str | None = None,
):
    df = try_read_csv(yahoo_csv)
    if df is None or df.empty:
        res = pd.DataFrame(columns=["fonte","ticker","rent_12m","volatilidade","beta"])
        if out_csv and os.path.isdir(os.path.dirname(out_csv)):
            save_csv(res, out_csv)
        return res

    df.columns = [c.lower() for c in df.columns]
    if "ticker" not in df.columns and "nome" in df.columns:
        df["ticker"] = df["nome"].astype(str).str.upper()
    elif "ticker" in df.columns:
        df["ticker"] = df["ticker"].astype(str).str.upper()

    if "rent_12m" in df.columns:
        df["rent_12m"] = pct_to_decimal_series(df["rent_12m"])
    elif "retorno_12m" in df.columns:
        df["rent_12m"] = pct_to_decimal_series(df["retorno_12m"])

    if "volatilidade" not in df.columns and "vol_12m" in df.columns:
        df["volatilidade"] = df["vol_12m"]

    beta_col = next((c for c in df.columns if "beta" in c), None)
    beta_series = pd.to_numeric(df[beta_col], errors="coerce") if beta_col else None

    df = df[~df["ticker"].map(_is_benchmark_like)]

    out = pd.DataFrame({
        "fonte": "YF",
        "ticker": df["ticker"],
        "rent_12m": df["rent_12m"] if "rent_12m" in df.columns else None,
        "volatilidade": df["volatilidade"] if "volatilidade" in df.columns else None,
    })
    if beta_series is not None:
        out["beta"] = beta_series

    if out_csv and os.path.isdir(os.path.dirname(out_csv)):
        save_csv(out, out_csv)
    return out
