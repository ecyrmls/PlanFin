# -*- coding: utf-8 -*-
from __future__ import annotations
import os
import pandas as pd
from typing import Optional, List
from .utils import try_read_csv, save_csv

def _guess_selected_products(resp: dict) -> Optional[List[str]]:
    for k, v in resp.items():
        lk = str(k).lower()
        if "agregador" in lk and ("prod" in lk or "categor" in lk):
            if isinstance(v, list):
                return [str(x) for x in v]
            if isinstance(v, str):
                return [v]
    return None

def filtrar_agregador(agregador_csv: str, respostas: dict, out_csv: str|None = None):
    df = try_read_csv(agregador_csv)
    if df is None or df.empty:
        res = pd.DataFrame(columns=["fonte","nome","produto","rentabilidade_liquida"])
        if out_csv and os.path.isdir(os.path.dirname(out_csv)):
            save_csv(res, out_csv)
        return res

    df.columns = [c.lower() for c in df.columns]
    nome_col = "nome" if "nome" in df.columns else None
    produto_col = "produto" if "produto" in df.columns else ("categoria" if "categoria" in df.columns else None)

    if "rentabilidade_liquida" not in df.columns:
        out = pd.DataFrame(columns=["fonte","nome","produto","rentabilidade_liquida"])
        if out_csv and os.path.isdir(os.path.dirname(out_csv)):
            save_csv(out, out_csv)
        return out

    sel = _guess_selected_products(respostas or {})
    if sel and produto_col:
        df = df[df[produto_col].astype(str).isin(sel)]

    out = pd.DataFrame({
        "fonte": "AGREGADOR_RF",
        "nome": df[nome_col] if nome_col else "",
        "produto": df[produto_col] if produto_col else "",
        "rentabilidade_liquida": df["rentabilidade_liquida"],
    })
    out["rent_12m"] = out["rentabilidade_liquida"]

    if out_csv and os.path.isdir(os.path.dirname(out_csv)):
        save_csv(out, out_csv)
    return out
