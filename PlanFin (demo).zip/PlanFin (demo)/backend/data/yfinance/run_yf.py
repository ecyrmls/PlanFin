#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
run_yf.py (robusto)
- Descobre automaticamente .../data/yfinance (YF_ROOT), mesmo rodando fora dela
- TZ America/Sao_Paulo para a pasta do dia
- Verifica comp_*.csv dentro de YF_ROOT
- Executa parse_yf.py índice a índice
- Grava saídas finais em YF_ROOT/YYYY-MM-DD/

Arquivos finais esperados na pasta do dia:
  - indices.csv
  - ibov.csv, idiv.csv, ifix.csv, ibrx50.csv, bdrx.csv, ismartdiv.csv, ibovlow.csv
"""

import os, sys, re, shutil, subprocess
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
import pandas as pd

INDICES = ["ibov", "idiv", "ifix", "ibrx50", "bdrx", "ismartdiv", "ibovlow"]
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


# -------- localização robusta da raiz data/yfinance --------
def find_yf_root(start: Path) -> Path | None:
    target_tail = os.path.join("data", "yfinance").replace("\\", "/")
    candidates = []

    def add_chain(anchor: Path):
        cur = anchor.resolve()
        for _ in range(8):
            candidates.append(cur / "data" / "yfinance")
            cur = cur.parent

    s = str(start).replace("\\", "/")
    if target_tail in s:
        parts = s.split("/")
        try:
            idx = len(parts) - 1 - parts[::-1].index("yfinance")
            candidates.insert(0, Path("/".join(parts[: idx + 1])))
        except ValueError:
            pass

    add_chain(start)
    add_chain(Path.cwd())

    uniq, seen = [], set()
    for c in candidates:
        key = str(c.resolve())
        if key not in seen:
            uniq.append(c)
            seen.add(key)

    for c in uniq:
        if c.is_dir() and (c / "parse_yf.py").is_file():
            return c.resolve()
    for c in uniq:
        if c.is_dir():
            return c.resolve()
    return None


# -------- paths e utilitários --------
def comp_files_map(yf_root: Path) -> dict:
    return {
        "ibov":      str(yf_root / "comp_ibov.csv"),
        "idiv":      str(yf_root / "comp_idiv.csv"),
        "ifix":      str(yf_root / "comp_ifix.csv"),
        "ibrx50":    str(yf_root / "comp_ibrx50.csv"),
        "bdrx":      str(yf_root / "comp_bdrx.csv"),
        "ismartdiv": str(yf_root / "comp_ismartdiv.csv"),
        "ibovlow":   str(yf_root / "comp_ibovlow.csv"),
    }

def today_sp() -> str:
    return datetime.now(ZoneInfo("America/Sao_Paulo")).strftime("%Y-%m-%d")

def ensure_day_dir(yf_root: Path, day: str) -> Path:
    day_dir = yf_root / day
    day_dir.mkdir(parents=True, exist_ok=True)
    return day_dir

def cleanup_old_days(yf_root: Path, keep_day: str):
    for name in os.listdir(yf_root):
        p = yf_root / name
        if p.is_dir() and DATE_RE.match(name) and name != keep_day:
            shutil.rmtree(p, ignore_errors=True)

def check_comp_files_present(files: dict) -> bool:
    missing = [k for k, v in files.items() if not os.path.exists(v)]
    if missing:
        print("[ERRO] Faltam arquivos de composição:", ", ".join(missing))
        for k in missing:
            print(f"  - esperado: {files[k]}")
        return False
    print("[VERIFICAÇÃO] Todos os arquivos de composição estão presentes.")
    return True

def run_parse_for_index(yf_root: Path, indice: str, comp_csv: str) -> int:
    parse_path = yf_root / "parse_yf.py"
    cmd = [sys.executable, str(parse_path), indice, comp_csv]
    # Executa com cwd=yf_root para que parse_yf.py grave seus temporários (_*_components/index) em YF_ROOT
    code = subprocess.call(cmd, cwd=str(yf_root))
    if code == 0:
        print(f"[OK] {indice} concluído.")
    else:
        print(f"[ERRO] {indice}: parse_yf.py retornou código {code}.")
    return code

def assemble_outputs(yf_root: Path, day_dir: Path):
    # índices (linhas únicas) → indices.csv
    index_tmp_paths = [yf_root / f"_{idx}_index.csv" for idx in INDICES]
    frames = []
    for p in index_tmp_paths:
        if p.exists() and p.stat().st_size > 0:
            frames.append(pd.read_csv(p))
    if frames:
        df_indices = pd.concat(frames, ignore_index=True)
    else:
        df_indices = pd.DataFrame(columns=[
            "ticker","preco","retorno_mes","retorno_ano","retorno_12m",
            "volatilidade","volume_medio","beta","tendencia","drawdown"
        ])
    (day_dir / "indices.csv").write_text(
        df_indices.to_csv(index=False), encoding="utf-8"
    )
    # components → {indice}.csv (ou CSV vazio com header se faltar)
    for idx in INDICES:
        src = yf_root / f"_{idx}_components.csv"
        dst = day_dir / f"{idx}.csv"
        if src.exists() and src.stat().st_size > 0:
            shutil.move(str(src), str(dst))
        else:
            empty = pd.DataFrame(columns=[
                "ticker","preco","retorno_mes","retorno_ano","retorno_12m",
                "volatilidade","volume_medio","beta","tendencia","drawdown"
            ])
            dst.write_text(empty.to_csv(index=False), encoding="utf-8")
    # limpa temporários de índices
    for p in index_tmp_paths:
        try:
            p.unlink()
        except Exception:
            pass

def verify_day_outputs(day_dir: Path) -> bool:
    expected = ["indices.csv"] + [f"{i}.csv" for i in INDICES]
    ok = True
    for name in expected:
        path = day_dir / name
        if not (path.exists() and path.stat().st_size > 0):
            print(f"[ALERTA] Arquivo ausente ou vazio: {path}")
            ok = False
    if ok:
        print("[OK] Todos os arquivos foram gerados com sucesso.")
    return ok


def main():
    # 1) Localiza YF_ROOT
    script_path = Path(__file__).resolve()
    start = script_path.parent
    yf_root = find_yf_root(start)
    if yf_root is None:
        print("[ERRO] Não foi possível localizar a pasta 'data/yfinance'.", file=sys.stderr)
        sys.exit(10)

    # 2) Define paths centrais (TZ São Paulo)
    today_str = today_sp()
    day_dir = ensure_day_dir(yf_root, today_str)
    cleanup_old_days(yf_root, today_str)

    print(f"[RUN] YF_ROOT: {yf_root}")
    print(f"[RUN] Pasta do dia: {day_dir}")

    # 3) Verifica comp_*.csv
    comp_map = comp_files_map(yf_root)
    print("[VERIFICAÇÃO] Checando arquivos de composição...")
    if not check_comp_files_present(comp_map):
        # importante: não seguir adiante; antes ficava um ensure_day_dir “perdido” após exit
        sys.exit(2)

    # 4) Executa parse índice a índice
    for idx in INDICES:
        code = run_parse_for_index(yf_root, idx, comp_map[idx])
        if code != 0:
            print("[ERRO] Abortando devido a falha no índice:", idx)
            sys.exit(code)

    # 5) Monta saídas finais
    assemble_outputs(yf_root, day_dir)
    verify_day_outputs(day_dir)
    print("[FINALIZADO] Processo finalizado. Saída em:", str(day_dir))


if __name__ == "__main__":
    main()
