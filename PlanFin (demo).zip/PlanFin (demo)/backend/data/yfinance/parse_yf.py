#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
parse_yf.py
Processa UM índice por execução, lendo comp_{indice}.csv (headers: ticker,participacao)
e gerando dois arquivos temporários no diretório base:
  _{indice}_components.csv  -> métricas por componente (sem o índice)
  _{indice}_index.csv       -> linha única do índice (mesmo schema)

As métricas por linha:
ticker,preco,retorno_mes,retorno_ano,retorno_12m,volatilidade,volume_medio,beta,tendencia,drawdown

Uso:
  python parse_yf.py <indice> <caminho_comp_csv>

Índices suportados e configuração de benchmark:
- ibov       → índice oficial (^BVSP)
- ibrx50     → índice oficial (^IBX50)
- idiv       → proxy ETF DIVO11.SA (rótulo em indices.csv = "IDIV*"), fallback ^IDIV/IDIV.SA
- ifix       → proxy ETF XFIX11.SA (rótulo = "IFIX*"), fallback ^IFIX/IFIX.SA
- ismartdiv  → proxy ETF NDIV11.SA (rótulo = "ISmartDIV*")
- ibovlow    → proxy ETF LVOL11.SA  (rótulo = "IBOVLow*")
- bdrx       → sem proxy; índice com linha vazia (rótulo = "BDRX")
"""
import os, sys, re, math
from typing import List
import pandas as pd
import numpy as np
import yfinance as yf

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Configuração de benchmark (candidatos em ordem de preferência) e rótulo do índice em indices.csv

INDEX_CONFIG = {
    "ibov":      {"bench_candidates": ["^BVSP"],            "label": "^BVSP"},
    "ibrx50":    {"bench_candidates": ["^IBX50"],           "label": "^IBX50"},
    "idiv":      {"bench_candidates": ["DIVO11.SA"],        "label": "IDIV*"},
    "ifix":      {"bench_candidates": ["XFIX11.SA"],        "label": "IFIX*"},
    "ismartdiv": {"bench_candidates": ["NDIV11.SA"],        "label": "ISmartDIV*"},
    "ibovlow":   {"bench_candidates": ["LVOL11.SA"],        "label": "IBOVLow*"},
    "bdrx":      {"bench_candidates": ["BDRX.SA"],          "label": "BDRX"},
    }

# Padrão de ticker B3 (aceita dígitos no meio, ex.: B3SA3, RRRP3, TAEE11)
TICKER_PATTERN = re.compile(r"^[A-Z0-9]{4}\d{1,2}$")

PERIOD = "1y"
INTERVAL = "1d"

def to_yahoo_ticker(t: str) -> str:
    t = str(t).strip().upper()
    if t.startswith("^"):
        return t
    if t.endswith(".SA"):
        return t
    if TICKER_PATTERN.match(t):
        return f"{t}.SA"
    return t

def read_comp_csv(path_csv: str) -> pd.DataFrame:
    df = pd.read_csv(path_csv, sep=None, engine="python")
    required = {"ticker", "participacao"}
    if not required.issubset(df.columns):
        raise ValueError(f"CSV {os.path.basename(path_csv)} deve conter headers: ticker,participacao")
    out = pd.DataFrame({
        "ticker_b3": df["ticker"].astype(str).str.upper().str.strip(),
        "peso_pct": pd.to_numeric(
            df["participacao"].astype(str).str.replace(".", "", regex=False).str.replace(",", ".", regex=False),
            errors="coerce"
        )
    }).dropna()
    soma = out["peso_pct"].sum()
    if soma > 0 and (soma < 99.0 or soma > 101.0):
        out["peso_pct"] = out["peso_pct"] * (100.0 / soma)
    return out

def compute_ranges(idx: pd.DatetimeIndex):
    last = idx.max()
    m_start = last.replace(day=1)
    start_m = idx[idx >= m_start].min()
    y_start = last.replace(month=1, day=1)
    start_y = idx[idx >= y_start].min()
    t_12m = last - pd.Timedelta(days=365)
    start_12 = idx[idx <= t_12m].max()
    return last, start_m, start_y, start_12

def compute_metrics(close: pd.Series, bench_close: pd.Series):
    c = close.dropna()
    if c.empty:
        return None
    idx = c.index
    last, start_m, start_y, start_12 = compute_ranges(idx)

    def ret_between(s, a, b):
        if a is None or b is None:
            return np.nan
        if a not in s.index or b not in s.index:
            return np.nan
        a_v, b_v = s.loc[a], s.loc[b]
        if pd.isna(a_v) or pd.isna(b_v):
            return np.nan
        return b_v / a_v - 1.0

    retorno_mes  = ret_between(c, start_m, last)
    retorno_ano  = ret_between(c, start_y, last)
    retorno_12m  = ret_between(c, start_12, last)

    daily_ret = c.pct_change().dropna()
    volatilidade = daily_ret.std() * (252 ** 0.5) if len(daily_ret) > 10 else np.nan

    if bench_close is not None and not bench_close.dropna().empty:
        bench_r = bench_close.pct_change().dropna()
        dr = daily_ret.reindex(bench_r.index).dropna()
        mr = bench_r.reindex(dr.index).dropna()
        if len(dr) > 10 and mr.var() > 0:
            beta = float(np.cov(dr, mr)[0, 1] / mr.var())
        else:
            beta = np.nan
    else:
        beta = np.nan

    ma20  = c.rolling(20).mean().iloc[-1] if len(c) >= 20 else np.nan
    ma50  = c.rolling(50).mean().iloc[-1] if len(c) >= 50 else np.nan
    ma200 = c.rolling(200).mean().iloc[-1] if len(c) >= 200 else np.nan
    tendencia = 1 if (pd.notna(ma20) and pd.notna(ma50) and pd.notna(ma200) and (ma20 > ma50 > ma200)) else \
                (-1 if (pd.notna(ma20) and pd.notna(ma50) and pd.notna(ma200) and (ma20 < ma50 < ma200)) else 0)

    rolling_max = c.cummax()
    dd_series = c / rolling_max - 1.0
    drawdown = dd_series.min() if len(dd_series) else np.nan

    preco = float(c.iloc[-1]) if len(c) else np.nan

    return {
        "preco": preco,
        "retorno_mes": float(retorno_mes) if pd.notna(retorno_mes) else np.nan,
        "retorno_ano": float(retorno_ano) if pd.notna(retorno_ano) else np.nan,
        "retorno_12m": float(retorno_12m) if pd.notna(retorno_12m) else np.nan,
        "volatilidade": float(volatilidade) if pd.notna(volatilidade) else np.nan,
        "beta": float(beta) if pd.notna(beta) else np.nan,
        "tendencia": int(tendencia) if pd.notna(tendencia) else 0,
        "drawdown": float(drawdown) if pd.notna(drawdown) else np.nan,
    }

def pick_bench_symbol(close_df: pd.DataFrame, candidates):
    for sym in candidates:
        s = close_df.get(sym)
        if s is not None and not s.dropna().empty:
            return sym
    return None

def yf_download_in_chunks(tickers: List[str], period: str, interval: str, chunk_size: int = 80) -> pd.DataFrame:
    chunks = [tickers[i:i+chunk_size] for i in range(0, len(tickers), chunk_size)]
    frames = []
    for ch in chunks:
        h = yf.download(
            tickers=ch,
            period=period,
            interval=interval,
            auto_adjust=True,
            actions=False,
            threads=True,
            progress=False
        )
        frames.append(h)
    if not frames:
        return pd.DataFrame()
    base = frames[0]
    for add in frames[1:]:
        base = base.join(add, how="outer")
    return base

def main():
    if len(sys.argv) < 3:
        print("Uso: python parse_yf.py <indice> <caminho_comp_csv>")
        sys.exit(2)

    indice = sys.argv[1].strip().lower()
    comp_path = os.path.abspath(sys.argv[2])
    if indice not in INDEX_CONFIG:
        print(f"[ERRO] Índice inválido: {indice}. Use: {', '.join(INDEX_CONFIG.keys())}")
        sys.exit(2)
    if not os.path.exists(comp_path):
        print(f"[ERRO] Arquivo de composição não encontrado: {comp_path}")
        sys.exit(2)

    cfg = INDEX_CONFIG[indice]
    bench_candidates = cfg["bench_candidates"]
    df_comp = read_comp_csv(comp_path)
    df_comp["ticker"] = df_comp["ticker_b3"].apply(to_yahoo_ticker)

    req_tickers = sorted(set(df_comp["ticker"].tolist() + bench_candidates))
    hist = yf_download_in_chunks(req_tickers, PERIOD, INTERVAL, chunk_size=80)

    if isinstance(hist.columns, pd.MultiIndex):
        close = hist["Close"].copy()
        volume = hist["Volume"].copy()
    else:
        close = hist[["Close"]].copy()
        volume = hist[["Volume"]].copy()

    bench_symbol = pick_bench_symbol(close, bench_candidates) if bench_candidates else None
    bench_close = close.get(bench_symbol) if bench_symbol else None
    label = cfg["label"]

    # Para BDRX: manter apenas o preço no indices.csv e não usar benchmark para beta dos componentes
    bench_for_beta = bench_close
    if indice == "bdrx":
        bench_for_beta = None  # força beta=NaN nos componentes


    index_rows = []
    if bench_close is not None and not bench_close.dropna().empty:
        bench_vol = volume.get(bench_symbol) if bench_symbol else None
        bench_vm = float(bench_vol.mean()) if bench_vol is not None and not bench_vol.dropna().empty else np.nan
        bm = compute_metrics(bench_close, bench_close)
        bm["ticker"] = label
        bm["volume_medio"] = bench_vm
        index_rows.append(bm)
    else:
        index_rows.append({
            "ticker": label,
            "preco": np.nan,
            "retorno_mes": np.nan,
            "retorno_ano": np.nan,
            "retorno_12m": np.nan,
            "volatilidade": np.nan,
            "volume_medio": np.nan,
            "beta": np.nan,
            "tendencia": 0,
            "drawdown": np.nan,
        })

    comp_rows = []
    missing = []
    for t in df_comp["ticker"]:
        c = close.get(t)
        if c is None or c.dropna().empty:
            missing.append(t)
            continue
        vol_series = volume.get(t)
        vol_medio = float(vol_series.mean()) if vol_series is not None and not vol_series.dropna().empty else np.nan
        m = compute_metrics(c, bench_for_beta)
        if m is None:
            missing.append(t)
            continue
        m["ticker"] = t
        m["volume_medio"] = vol_medio
        comp_rows.append(m)

    comps_df = pd.DataFrame(comp_rows, columns=[
        "ticker","preco","retorno_mes","retorno_ano","retorno_12m",
        "volatilidade","volume_medio","beta","tendencia","drawdown"
    ]).sort_values("ticker")

    index_df = pd.DataFrame(index_rows, columns=[
        "ticker","preco","retorno_mes","retorno_ano","retorno_12m",
        "volatilidade","volume_medio","beta","tendencia","drawdown"
    ])

    out_comp_tmp = os.path.join(BASE_DIR, f"_{indice}_components.csv")
    out_index_tmp = os.path.join(BASE_DIR, f"_{indice}_index.csv")
    comps_df.to_csv(out_comp_tmp, index=False, encoding="utf-8")
    index_df.to_csv(out_index_tmp, index=False, encoding="utf-8")

    print(f"[OK] {indice} concluído.")
    if missing:
        print(f"[WARN] {indice}: tickers sem dados no Yahoo (ignorados): {', '.join(missing[:10])}{'...' if len(missing)>10 else ''}")

if __name__ == "__main__":
    main()
