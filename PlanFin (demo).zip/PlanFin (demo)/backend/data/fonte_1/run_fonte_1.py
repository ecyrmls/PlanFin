# run_fonte_1.py — Runner para Fonte 1 (coleta de fundos)
from __future__ import annotations

import os
import re
import sys
import shutil
import subprocess
from pathlib import Path
from datetime import datetime

try:
    from zoneinfo import ZoneInfo
except Exception:
    ZoneInfo = None

RAW_CSV_NAME = "fundos_fonte_1.csv"
DATE_DIR_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
SCRIPT_DIR = Path(__file__).resolve().parent


def today_sp_iso() -> str:
    if ZoneInfo is None:
        return datetime.now().date().isoformat()
    return datetime.now(ZoneInfo("America/Sao_Paulo")).date().isoformat()


def list_date_dirs(base: Path) -> list[Path]:
    try:
        return sorted([p for p in base.iterdir() if p.is_dir() and DATE_DIR_RE.match(p.name)])
    except FileNotFoundError:
        return []


def ensure_today_dir(base: Path) -> Path:
    base.mkdir(parents=True, exist_ok=True)
    d = base / today_sp_iso()
    d.mkdir(parents=True, exist_ok=True)
    return d


def delete_older_date_dirs(base: Path, keep_dir: Path) -> None:
    keep_name = keep_dir.name
    for entry in list_date_dirs(base):
        if entry.name < keep_name:
            try:
                shutil.rmtree(entry)
                print(f"[INFO] Excluída pasta antiga: {entry}")
            except Exception as e:
                print(f"[WARN] Falha ao excluir {entry}: {e}", file=sys.stderr)


def move_csv_to_today(csv_path: Path, today_dir: Path) -> Path:
    target = today_dir / csv_path.name
    try:
        if target.exists():
            target.unlink()
        shutil.move(str(csv_path), str(target))
        return target
    except Exception as e:
        print(f"[ERRO] Falha ao mover CSV para {today_dir}: {e}", file=sys.stderr)
        sys.exit(4)


def assert_csv_generated(base: Path, csv_name: str) -> Path:
    csv_path = base / csv_name
    if not csv_path.exists():
        print(f"[ERRO] Arquivo {csv_name} não foi gerado em {base}", file=sys.stderr)
        sys.exit(2)
    if csv_path.stat().st_size == 0:
        print(f"[ERRO] Arquivo {csv_name} está vazio em {base}", file=sys.stderr)
        sys.exit(3)
    return csv_path


def run_parser(parser_path: Path, output_dir: Path) -> int:
    env = os.environ.copy()
    env["FONTE1_OUTPUT_DIR"] = str(output_dir)
    cmd = [sys.executable, str(parser_path)]
    print(f"[RUN] Chamando parser...")
    try:
        proc = subprocess.run(cmd, check=False, env=env)
        return proc.returncode
    except Exception as e:
        print(f"[ERRO] Falha ao executar o parser: {e}", file=sys.stderr)
        return 1


def main():
    os.environ["TZ"] = "America/Sao_Paulo"

    fonte1_root = SCRIPT_DIR
    parser_path = fonte1_root / "parse_fonte_1.py"
    
    if not parser_path.exists():
        print(f"[ERRO] Parser não encontrado: {parser_path}", file=sys.stderr)
        sys.exit(10)

    output_base = fonte1_root

    print(f"[RUN] Iniciando rotina Fonte 1. Diretório base: {output_base}")
    today_str = today_sp_iso()
    print(f"[RUN] Data de execução (America/Sao_Paulo): {today_str}")

    today_dir = ensure_today_dir(output_base)
    print(f"[RUN] Pasta do dia garantida: {today_dir}")

    rc = run_parser(parser_path, output_base)
    if rc != 0:
        print(f"[ERRO] Parser retornou código {rc}. Interrompendo.", file=sys.stderr)
        sys.exit(rc)

    csv_path = assert_csv_generated(output_base, RAW_CSV_NAME)
    delete_older_date_dirs(output_base, today_dir)
    final_csv = move_csv_to_today(csv_path, today_dir)

    print("[OK] Rotina Fonte 1 concluída com sucesso.")
    print(f"[OK] CSV final: {final_csv}")


if __name__ == "__main__":
    main()
