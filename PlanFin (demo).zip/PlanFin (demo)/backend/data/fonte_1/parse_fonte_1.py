# parse_fonte_1.py
# Coleta fundos da Fonte 1 via API e gera CSV com nomes anonimizados
import os
import sys
import requests
import pandas as pd
from pathlib import Path
from typing import Any, Dict, List, Optional

# Adicionar backend ao path para importar crypto_utils
SCRIPT_DIR = Path(__file__).parent.resolve()
BACKEND_DIR = SCRIPT_DIR.parent.parent
sys.path.insert(0, str(BACKEND_DIR))

try:
    from crypto_utils import carregar_config_json
    HAS_CRYPTO = True
except ImportError:
    HAS_CRYPTO = False

# Carregar configuração (criptografada ou fallback)
SENHA = os.environ.get("PLANFIN_SENHA")
if not SENHA:
    print("[AVISO] PLANFIN_SENHA não definida. Configure nas variáveis de ambiente.")
    SENHA = None
CONFIG_ENC = SCRIPT_DIR / "config.enc"
PREFIXO_ANONIMO = "F_1_"

if HAS_CRYPTO and CONFIG_ENC.exists() and SENHA:
    try:
        CONFIG = carregar_config_json(CONFIG_ENC, SENHA)
        ENDPOINT = CONFIG["endpoint"]
        PREFIXO_ANONIMO = CONFIG.get("prefixo_anonimo", "F_1_")
        print(f"[OK] Configuração carregada de config.enc")
    except Exception as e:
        print(f"[WARN] Falha ao carregar config.enc: {e}")
        ENDPOINT = os.environ.get("FONTE1_ENDPOINT", "https://api.fonte1.exemplo.com/fundos")
else:
    ENDPOINT = os.environ.get("FONTE1_ENDPOINT", "https://api.fonte1.exemplo.com/fundos")

OUTPUT_DIR = Path(os.environ.get("FONTE1_OUTPUT_DIR", "/app/data/fonte_1"))
OUTPUT_CSV = OUTPUT_DIR / "fundos_fonte_1.csv"

# --------- Regras de normalização/filtragem ---------
RISK_MAP = {
    "CONSERVADOR": "Baixo",
    "MODERADO": "Médio",
    "SOFISTICADO": "Alto",
}

CATEGORY_EXCLUDE = {
    "Fundos de Participações",
    "Investimento Imobiliário",
}
CATEGORY_RENAME = {
    "Multimercados": "Multimercado",
    "Ações": "Renda Variável",
}

ALLOWED_ADMIN_FEE_TYPE = {"PERCENTAGE"}
ALLOWED_FUND_TYPE_PMS = {"Fundo de Investimento", "Fundo de Previdência"}
ALLOWED_INVESTMENT_TYPE = {"Investidores em geral (Não qualificados)"}

# Campos desejados para projeção
PROFIT_FIELDS = [
    "sharpeTwelveMonths",
    "year",
    "lastMonth",
    "twelveMonthsCDI",
    "twelveMonths",
    "lastYearCDI",
    "month",
    "lastYear",
    "volatilityTwelveMonths",
]
DETAIL_FIELDS = [
    "administrationFee",
    "performanceFee",
    "categoryCVM",
    "minimumMoviment",
    "administrationFeeType",
    "managementFee",
    "totalFee",
]
TOP_FIELDS = [
    "riskName",
    "rescueOpen",
    "fund175",
    "netEquity",
    "fundTypePMS",
    "applyOpen",
    "fundName",
    "minimumInitialInvestment",
    "isentoIR",
    "investmentType",
    "offerPF",
    "numeroDiaFinanceiroResgate",
]

# Mapeamento de renomeação/ordem no CSV final
CSV_RENAME_ORDER = [
    ("fundName", "nome"),
    ("detail.categoryCVM", "categoria"),
    ("minimumInitialInvestment", "aplic_min"),
    ("detail.administrationFee", "taxa_adm"),
    ("riskName", "risco"),
    ("profitability.month", "rent_mes"),
    ("profitability.year", "rent_ano"),
    ("profitability.twelveMonths", "rent_12m"),
]

FILTER_ONLY_COLUMNS = {
    "investmentType",
    "fundTypePMS",
    "applyOpen",
    "rescueOpen",
    "fund175",
    "offerPF",
    "detail.administrationFeeType",
}

# -------------------- util --------------------
def safe_get(d: Dict[str, Any], path: str, default: Any = None) -> Any:
    cur = d
    for part in path.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return default
        cur = cur[part]
    return cur

def coerce_intlike_to_str_with_prefix(value: Any, prefix: str = "D+") -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, str):
        val = value.strip()
        if val.upper().startswith("D+"):
            return val
        try:
            n = int(val)
            return f"{prefix}{n}"
        except ValueError:
            return f"{prefix}{val}"
    if isinstance(value, (int, float)):
        return f"{prefix}{int(value)}"
    return f"{prefix}{value}"

def normalize_category(category: Optional[str]) -> Optional[str]:
    if category is None:
        return None
    if category in CATEGORY_EXCLUDE:
        return "__EXCLUDE__"
    return CATEGORY_RENAME.get(category, category)

def normalize_risk(risk: Optional[str]) -> Optional[str]:
    if risk is None:
        return None
    return RISK_MAP.get(risk, risk)

def extract_funds(payload: Any) -> List[Dict[str, Any]]:
    if isinstance(payload, list):
        return payload
    if isinstance(payload, dict):
        for key in ("data", "content", "items", "result", "funds"):
            if key in payload and isinstance(payload[key], list):
                return payload[key]
        for v in payload.values():
            if isinstance(v, list) and v and isinstance(v[0], dict):
                return v
    raise ValueError("Não foi possível identificar a lista de fundos no payload recebido.")

# -------------------- filtros --------------------
def fund_passes_filters(f: Dict[str, Any]) -> bool:
    if safe_get(f, "isCetipFund") is not False:
        return False
    if safe_get(f, "rescueOpen") is not True:
        return False
    if safe_get(f, "fund175") is not True:
        return False
    if safe_get(f, "applyOpen") is not True:
        return False
    if safe_get(f, "offerPF") is not True:
        return False

    if safe_get(f, "detail.administrationFeeType") not in ALLOWED_ADMIN_FEE_TYPE:
        return False
    if safe_get(f, "fundTypePMS") not in ALLOWED_FUND_TYPE_PMS:
        return False
    if safe_get(f, "investmentType") not in ALLOWED_INVESTMENT_TYPE:
        return False

    if normalize_category(safe_get(f, "detail.categoryCVM")) == "__EXCLUDE__":
        return False

    return True

# -------------------- projeção --------------------
def project_fields(f: Dict[str, Any]) -> Dict[str, Any]:
    out: Dict[str, Any] = {}

    # Top-level
    for k in TOP_FIELDS:
        val = safe_get(f, k)
        if k == "riskName":
            val = normalize_risk(val)
        elif k == "numeroDiaFinanceiroResgate":
            val = coerce_intlike_to_str_with_prefix(val, "D+")
        out[k] = val

    # detail.*
    detail_obj = safe_get(f, "detail", {})
    cat = normalize_category(detail_obj.get("categoryCVM"))
    if cat == "__EXCLUDE__":
        cat = None
    for k in DETAIL_FIELDS:
        out[f"detail.{k}"] = detail_obj.get(k)
    out["detail.categoryCVM"] = cat

    # profitability.*
    prof_obj = safe_get(f, "profitability", {})
    for k in PROFIT_FIELDS:
        out[f"profitability.{k}"] = prof_obj.get(k)

    return out

# -------------------- CSV --------------------
def _to_decimal(value: Any) -> Optional[float]:
    if value is None:
        return None
    try:
        v = float(value)
        if abs(v) > 1:
            return round(v / 100.0, 6)
        return round(v, 6)
    except (ValueError, TypeError):
        return None

def build_csv(raw_df: pd.DataFrame) -> pd.DataFrame:
    df = raw_df.copy()

    # 1) Remover colunas que são só para filtro
    to_drop = [c for c in FILTER_ONLY_COLUMNS if c in df.columns]
    df = df.drop(columns=to_drop, errors="ignore")

    # 2) Converter rentabilidades para DECIMAL
    rent_cols_raw = [
        "profitability.month",
        "profitability.year",
        "profitability.twelveMonths",
    ]
    for col in rent_cols_raw:
        if col in df.columns:
            df[col] = df[col].apply(_to_decimal)

    # 3) Renomear colunas especificadas
    rename_map = {src: dst for src, dst in CSV_RENAME_ORDER}
    df = df.rename(columns=rename_map)

    # 4) Ordenar colunas
    first_cols = [dst for _, dst in CSV_RENAME_ORDER if dst in df.columns]
    remaining_cols = [c for c in df.columns if c not in first_cols]
    return df[first_cols + remaining_cols]

# -------------------- main --------------------
def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    print(f"[FONTE1] Baixando dados do endpoint...")
    try:
        resp = requests.get(ENDPOINT, timeout=60)
        resp.raise_for_status()
        payload = resp.json()
    except Exception as e:
        print(f"[ERRO] Falha na requisição: {e}")
        sys.exit(1)

    # extrair
    funds = extract_funds(payload)
    print(f"[FONTE1] Fundos retornados: {len(funds)}")

    # filtrar
    filtered = [f for f in funds if fund_passes_filters(f)]
    print(f"[FONTE1] Após filtros: {len(filtered)} fundos")

    # projetar
    rows = [project_fields(f) for f in filtered]
    if not rows:
        pd.DataFrame(columns=[dst for _, dst in CSV_RENAME_ORDER]).to_csv(OUTPUT_CSV, index=False, encoding="utf-8")
        print(f"[FONTE1] Nenhum fundo após filtros. CSV vazio gerado em: {OUTPUT_CSV}")
        return

    # CSV final (com conversão p/ decimais)
    raw_df = pd.DataFrame(rows)
    final_df = build_csv(raw_df)
    
    # ========== ANONIMIZAÇÃO ==========
    # Substituir nomes de fundos por IDs anônimos
    if "nome" in final_df.columns:
        nome_map = {}
        for i, nome_original in enumerate(final_df["nome"].unique(), start=1):
            nome_map[nome_original] = f"{PREFIXO_ANONIMO}{i:04d}"
        final_df["nome"] = final_df["nome"].map(nome_map)
        print(f"[FONTE1] {len(nome_map)} fundos anonimizados")
    # ==================================
    
    final_df.to_csv(OUTPUT_CSV, index=False, encoding="utf-8")

    print(f"[FONTE1] CSV gerado com sucesso em: {OUTPUT_CSV}")
    print(f"[FONTE1] Colunas (CSV): {list(final_df.columns)}")
    print(f"[FONTE1] Linhas: {len(final_df)}")

if __name__ == "__main__":
    main()
