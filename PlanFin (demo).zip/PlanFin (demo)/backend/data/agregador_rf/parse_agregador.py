# parse_agregador.py
# Parser para Agregador de Renda Fixa
# Coleta dados de títulos e anonimiza nomes com T_0001, T_0002, etc.

import sys
import os
import time
import re
import csv
import requests
from pathlib import Path
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse
from bs4 import BeautifulSoup

# Criptografia
SCRIPT_DIR = Path(__file__).parent.resolve()
BACKEND_DIR = SCRIPT_DIR.parent.parent
sys.path.insert(0, str(BACKEND_DIR))

from crypto_utils import carregar_urls_requests

SENHA = os.environ.get("PLANFIN_SENHA")
if not SENHA:
    print("[AVISO] PLANFIN_SENHA não definida. Configure nas variáveis de ambiente.")
SUFFIX = os.environ.get("PLANFIN_AGREGADOR_PERIOD_SUFFIX", "1m")
REQUESTS_FILE = SCRIPT_DIR / f"requests_agregador_{SUFFIX}.txt.enc"
OUTPUT_CSV = SCRIPT_DIR / "agregador.csv"

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    )
}

# Contador global para anonimização
NOME_CONTADOR = {"valor": 0}
NOME_MAP = {}

def anonimizar_nome(nome: str) -> str:
    """Anonimiza nome com T_0001, T_0002, etc."""
    if nome not in NOME_MAP:
        NOME_CONTADOR["valor"] += 1
        NOME_MAP[nome] = f"T_{NOME_CONTADOR['valor']:04d}"
    return NOME_MAP[nome]

def set_query_param(url: str, key: str, value: str) -> str:
    parsed = urlparse(url)
    qs = parse_qs(parsed.query, keep_blank_values=True)
    qs[key] = [str(value)]
    new_query = urlencode(qs, doseq=True)
    return urlunparse((parsed.scheme, parsed.netloc, parsed.path, parsed.params, new_query, parsed.fragment))

def require_collection_page_1(url: str) -> None:
    parsed = urlparse(url)
    qs = parse_qs(parsed.query, keep_blank_values=True)
    if "collection_page" not in qs:
        raise ValueError("URL sem parâmetro obrigatório 'collection_page'. Esperado 'collection_page=1'.")
    vals = qs["collection_page"]
    if not vals or vals[0] != "1":
        raise ValueError(f"URL inválida: esperado 'collection_page=1', encontrado 'collection_page={vals[0] if vals else None}'.")

def _to_number(text: str) -> float:
    t = text.strip()
    t = re.sub(r"[^0-9,.\-]", "", t)
    if "," in t and "." in t:
        t = t.replace(".", "")
    t = t.replace(",", ".")
    return float(t) if t else 0.0

def percent_to_decimal(text: str) -> float:
    return _to_number(text) / 100.0

def get_required_th_value(container, th_label_exact: str) -> str:
    th = container.find("th", attrs={"scope": "row"}, string=lambda s: isinstance(s, str) and s.strip() == th_label_exact)
    if th is None:
        raise ValueError(f"Tag <th scope='row'> com texto exato '{th_label_exact}' não encontrada dentro do card.")
    td = th.find_next_sibling("td")
    if td is None:
        raise ValueError(f"<td> para '{th_label_exact}' não encontrado dentro do card.")
    return td.get_text(strip=True)

def extract_card_data(card) -> dict:
    # [produto] — h4.badge dentro de div.cluster.cluster--center
    cluster = card.find("div", class_="cluster cluster--center")
    if cluster is None:
        raise ValueError("<div class='cluster cluster--center'> não encontrado dentro do card.")
    h4_badge = cluster.find("h4", class_=lambda classes: classes and "badge" in classes)
    if h4_badge is None:
        raise ValueError("<h4 class='badge ...'> do produto não encontrado dentro do card.")
    produto = h4_badge.get_text(strip=True)

    # [nome]
    h3 = card.find("h3", class_="flex-stack font-size--s0")
    if h3 is None:
        raise ValueError("Heading <h3 class='flex-stack font-size--s0'> não encontrado dentro do card.")
    strong = h3.find("strong")
    if strong is None:
        raise ValueError("<strong> do nome não encontrado dentro do heading do card.")
    nome = strong.get_text(strip=True)
    nome = nome.replace(",", ".")
    
    # ANONIMIZAÇÃO
    nome = anonimizar_nome(nome)

    # Rentabilidade bruta → decidir entre CDI (percentual do CDI) e anual (% a.a.)
    gross = card.find("div", class_="results__grossYield")
    if gross is None:
        raise ValueError("<div class='results__grossYield'> não encontrado dentro do card.")
    big = gross.find("big")
    if big is None:
        raise ValueError("<big> dentro de .results__grossYield não encontrado.")

    span_number = big.find("span", class_="sugarish__number")
    if span_number is None:
        raise ValueError("span.sugarish__number da rentabilidade bruta não encontrado em .results__grossYield.")
    span_cdi = big.find("span", class_="sugarish__cdi")
    if span_cdi is None:
        raise ValueError("span.sugarish__cdi não encontrado em .results__grossYield.")

    bruta_num = span_number.get_text(strip=True)
    bruta_tag = span_cdi.get_text(strip=True)

    rentabilidade_bruta_cdi = ""
    rentabilidade_bruta_anual = ""

    if bruta_tag == "CDI":
        rentabilidade_bruta_cdi = f"{percent_to_decimal(bruta_num):.6f}"
    elif bruta_tag == "a.a.":
        rentabilidade_bruta_anual = f"{percent_to_decimal(bruta_num):.6f}"
    else:
        raise ValueError(f"Valor inesperado em sugarish__cdi: '{bruta_tag}' (esperado 'CDI' ou 'a.a.').")

    rentabilidade_liquida_text = get_required_th_value(card, "Rentabilidade líquida ao ano")
    investimento_minimo_text  = get_required_th_value(card, "Investimento mínimo")

    rentabilidade_liquida = f"{percent_to_decimal(rentabilidade_liquida_text):.6f}"
    investimento_minimo   = f"{_to_number(investimento_minimo_text):.2f}"

    return {
        "produto": produto,
        "nome": nome,
        "rentabilidade_bruta_cdi": rentabilidade_bruta_cdi,
        "rentabilidade_bruta_anual": rentabilidade_bruta_anual,
        "rentabilidade_liquida": rentabilidade_liquida,
        "investimento_minimo": investimento_minimo,
    }

def find_card_containers(soup: BeautifulSoup):
    candidates = []
    for h3 in soup.find_all("h3", class_="flex-stack font-size--s0"):
        found_card = None
        for ancestor in h3.parents:
            if ancestor is None or getattr(ancestor, "name", None) is None:
                continue

            cluster = ancestor.find("div", class_="cluster cluster--center")
            ok_produto = False
            if cluster is not None:
                h4_badge = cluster.find("h4", class_=lambda classes: classes and "badge" in classes)
                ok_produto = h4_badge is not None

            ok_nome = ancestor.find("h3", class_="flex-stack font-size--s0") is not None and ancestor.find("h3", class_="flex-stack font-size--s0").find("strong") is not None

            gross = ancestor.find("div", class_="results__grossYield")
            ok_bruta = False
            if gross is not None:
                big = gross.find("big")
                if big is not None:
                    has_num = big.find("span", class_="sugarish__number") is not None
                    has_cdi = big.find("span", class_="sugarish__cdi") is not None
                    ok_bruta = has_num and has_cdi

            ok_liq = ancestor.find("th", attrs={"scope": "row"}, string=lambda s: isinstance(s, str) and s.strip() == "Rentabilidade líquida ao ano") is not None
            ok_min = ancestor.find("th", attrs={"scope": "row"}, string=lambda s: isinstance(s, str) and s.strip() == "Investimento mínimo") is not None

            if ok_produto and ok_nome and ok_bruta and ok_liq and ok_min:
                found_card = ancestor
                break

        if found_card is not None:
            candidates.append(found_card)

    seen = set()
    unique = []
    for c in candidates:
        key = id(c)
        if key not in seen:
            seen.add(key)
            unique.append(c)
    return unique

def process_link(original_url: str, total_counter: dict, writer) -> None:
    require_collection_page_1(original_url)

    page = 1
    collected_in_link = 0
    while True:
        url = set_query_param(original_url, "collection_page", str(page))
        print(f"[RUN] Página {page}")
        resp = requests.get(url, headers=HEADERS, timeout=30)
        if resp.status_code != 200:
            sys.exit(2)

        soup = BeautifulSoup(resp.text, "html.parser")
        cards = find_card_containers(soup)
        if not cards:
            print(f"[OK] Nenhum card encontrado na página {page}.")
            break

        page_count = 0
        for card in cards:
            data = extract_card_data(card)
            page_count += 1
            total_counter["total"] += 1
            collected_in_link += 1
            writer.writerow([
                data["produto"],
                data["nome"],
                data["rentabilidade_bruta_cdi"],
                data["rentabilidade_bruta_anual"],
                data["rentabilidade_liquida"],
                data["investimento_minimo"],
            ])

        print(f"[OK] Página {page}: {page_count} cards válidos.")
        page += 1
        time.sleep(0.8)

    print(f"[OK] Link finalizado: {collected_in_link} cards válidos coletados.")

def main():
    # Carregar URLs do arquivo criptografado
    if not REQUESTS_FILE.exists():
        print(f"[ERRO] Arquivo não encontrado: {REQUESTS_FILE}")
        sys.exit(2)

    print(f"[RUN] Usando arquivo de requests: {REQUESTS_FILE}")
    lines = carregar_urls_requests(REQUESTS_FILE, SENHA)

    if not lines:
        print("[ERRO] Nenhuma URL carregada")
        sys.exit(2)

    print(f"[OK] {len(lines)} URLs carregadas")

    total_counter = {"total": 0}

    with OUTPUT_CSV.open("w", newline="", encoding="utf-8") as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow([
            "produto",
            "nome",
            "rentabilidade_bruta_cdi",
            "rentabilidade_bruta_anual",
            "rentabilidade_liquida",
            "investimento_minimo",
        ])

        for idx, original_url in enumerate(lines, start=1):
            print(f"[RUN] Link {idx}/{len(lines)} -> {original_url}")
            process_link(original_url, total_counter, writer)

    print(f"[DONE] Total de cards coletados: {total_counter['total']}")

if __name__ == "__main__":
    try:
        main()
    except Exception:
        sys.exit(1)
