# run_agregador.py
# Fluxo de coleta de títulos de renda fixa do agregador
# Mudança: copia o .enc do período correto para requests_agregador_1m.txt.enc
import os, re, sys, shutil, subprocess
from datetime import datetime, timedelta
from pathlib import Path

try:
    from zoneinfo import ZoneInfo  # Python 3.9+
except Exception:
    ZoneInfo = None

BASE_DIR = Path(os.environ.get("PLANFIN_AGREGADOR_BASE_DIR", "/app/data/agregador_rf")).resolve()
PARSER_PATH = BASE_DIR / "parse_agregador.py"
SRC_CSV     = BASE_DIR / "agregador.csv"
KEEP_DAYS   = int(os.environ.get("PLANFIN_AGREGADOR_KEEP_DAYS", "7"))
TZ_NAME     = os.environ.get("PLANFIN_TZ", "America/Sao_Paulo")

def today_str_tz(tz_name: str) -> str:
    if ZoneInfo is None:
        dt = datetime.utcnow() - timedelta(hours=3)
    else:
        dt = datetime.now(ZoneInfo(tz_name))
    return dt.strftime("%Y-%m-%d")

def ensure_dir(p: Path):
    p.mkdir(parents=True, exist_ok=True)

def cleanup_old_days(base: Path, keep_days: int):
    try:
        cutoff = (datetime.now(ZoneInfo(TZ_NAME)) if ZoneInfo else datetime.utcnow()) - timedelta(days=keep_days)
    except Exception:
        cutoff = datetime.utcnow() - timedelta(days=keep_days)
    removed = 0
    for child in base.iterdir():
        if child.is_dir() and re.fullmatch(r"\d{4}-\d{2}-\d{2}", child.name):
            try:
                day_dt = datetime.strptime(child.name, "%Y-%m-%d")
            except ValueError:
                continue
            if day_dt < cutoff.replace(tzinfo=None):
                try:
                    shutil.rmtree(child)
                    print(f"[OK] Pasta antiga removida: {child}")
                    removed += 1
                except Exception as e:
                    print(f"[ERRO] Falha ao remover {child}: {e}")
                    sys.exit(2)
    if removed == 0:
        print("[OK] Nenhuma pasta antiga para remover.")

def extract_suffix_from_requests(path: Path) -> str:
    # Aceita .txt ou .txt.enc
    m = re.search(r"requests_agregador_(.+?)\.txt(?:\.enc)?$", path.name)
    if not m:
        print(f"[ERRO] Não foi possível extrair sufixo de '{path.name}'.")
        sys.exit(2)
    return m.group(1)

def resolve_requests_file() -> Path:
    """Resolve qual arquivo .enc usar baseado no sufixo"""
    by_file = os.environ.get("PLANFIN_AGREGADOR_REQUESTS_FILE", "").strip()
    if by_file:
        p = Path(by_file).resolve()
        print(f"[RUN] Usando PLANFIN_AGREGADOR_REQUESTS_FILE: {p}")
        return p
    by_suffix = os.environ.get("PLANFIN_AGREGADOR_PERIOD_SUFFIX", "").strip()
    if by_suffix:
        if not re.fullmatch(r"\d+m", by_suffix):
            print(f"[ERRO] PLANFIN_AGREGADOR_PERIOD_SUFFIX inválido: '{by_suffix}'.")
            sys.exit(2)
        p = BASE_DIR / f"requests_agregador_{by_suffix}.txt.enc"
        print(f"[RUN] Usando PLANFIN_AGREGADOR_PERIOD_SUFFIX='{by_suffix}': {p}")
        return p
    p = BASE_DIR / "requests_agregador_1m.txt.enc"
    print(f"[RUN] Usando fallback: {p}")
    return p

def run_parser():
    if not PARSER_PATH.exists():
        print(f"[ERRO] Parser não encontrado: {PARSER_PATH}")
        sys.exit(2)
    print(f"[RUN] Executando parser: {PARSER_PATH}")
    env = os.environ.copy()
    proc = subprocess.run([sys.executable, str(PARSER_PATH)], cwd=str(PARSER_PATH.parent), env=env)
    if proc.returncode != 0:
        print(f"[ERRO] Parser retornou código {proc.returncode}. Interrompendo.")
        sys.exit(2)

def is_csv_nonempty(csv_path: Path) -> bool:
    if not csv_path.exists():
        return False
    try:
        with csv_path.open("r", encoding="utf-8") as f:
            for i, _ in enumerate(f, start=1):
                if i > 1:
                    return True
            return False
    except Exception:
        return False

def main():
    print(f"[RUN] Iniciando rotina Agregador RF. Diretório base: {BASE_DIR}")
    if not BASE_DIR.exists():
        print(f"[ERRO] Diretório base não existe: {BASE_DIR}")
        sys.exit(2)

    requests_file = resolve_requests_file()
    if not requests_file.exists():
        print(f"[ERRO] Arquivo de requests não encontrado: {requests_file}")
        sys.exit(2)

    d_str = today_str_tz(TZ_NAME)
    print(f"[RUN] Data de execução ({TZ_NAME}): {d_str}")

    suffix = extract_suffix_from_requests(requests_file)
    print(f"[RUN] Sufixo detectado: {suffix}")

    day_dir = BASE_DIR / d_str
    ensure_dir(day_dir)
    print(f"[RUN] Pasta do dia garantida: {day_dir}")

    suffix_dir = day_dir / suffix
    ensure_dir(suffix_dir)
    print(f"[RUN] Pasta do sufixo garantida: {suffix_dir}")

    print(f"[RUN] Removendo pastas antigas (> {KEEP_DAYS} dias)...")
    cleanup_old_days(BASE_DIR, KEEP_DAYS)

    run_parser()

    if not is_csv_nonempty(SRC_CSV):
        print(f"[ERRO] CSV de saída ausente ou vazio: {SRC_CSV}")
        sys.exit(2)

    dest_csv = suffix_dir / f"titulos_agregador_{suffix}.csv"
    try:
        if dest_csv.exists():
            dest_csv.unlink()
        shutil.move(str(SRC_CSV), str(dest_csv))
    except Exception as e:
        print(f"[ERRO] Falha ao mover CSV para {dest_csv}: {e}")
        sys.exit(2)

    print(f"[OK] CSV do dia gerado: {dest_csv}")
    print("[DONE] Rotina Agregador RF concluída com sucesso.")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"[ERRO] {e}")
        sys.exit(1)
