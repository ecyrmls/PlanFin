#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
parse_fonte_2.py
Lê endpoints do arquivo requests_fonte_2.txt, consome os JSONs da Fonte 2 (page-data)
e gera fundos_fonte_2.csv padronizado.

Regras aplicadas:
- status -> manter apenas contendo "ATIVO" (case-insensitive). Não vai para o CSV.
- investorProfile -> manter apenas "Investidores em geral" (case-insensitive). Não vai para o CSV.
- Excluir fundos com in12Months vazio/nulo OU profitYear vazio/nulo.
- cvmClassification: "Cambial" -> "Internacional".
- risk.label: "Muito baixo" -> "Baixo"; "Muito alto" -> "Alto".
- Converter % -> decimal em: in12Months (rent_12m), profitMonth (rent_mes),
  profitYear (rent_ano), adminFee.current (taxa_adm).
- Remover do CSV: status, fundClass, investorProfile.
- performanceFee.previous: limpar "não há/possui" (variações) e 0 -> vazio.

CSV final (ordem):
  nome, categoria, aplic_min, taxa_adm, cot_res, liqu_res, risco,
  rent_mes, rent_ano, rent_12m, performanceFee_previous
"""

import argparse
import csv
import re
import sys
import requests
from pathlib import Path
from typing import Any, Dict, List, Optional

HTTP_TIMEOUT = 30

CSV_COLUMNS = [
    "nome",
    "categoria",
    "aplic_min",
    "taxa_adm",
    "cot_res",
    "liqu_res",
    "risco",
    "rent_mes",
    "rent_ano",
    "rent_12m",
    "performanceFee_previous",
]

# ---------------- Utils ----------------

def _to_str(x: Any) -> str:
    return "" if x is None else str(x).strip()

def _to_float(x: Any) -> Optional[float]:
    if x is None:
        return None
    s = str(x).strip().replace("R$", "").replace(".", "").replace(" ", "")
    s = s.replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return None

def _percent_to_decimal(x: Any) -> Optional[float]:
    if x is None:
        return None
    s = str(x).strip().replace(" ", "").replace(",", ".")
    if s == "":
        return None
    if s.endswith("%"):
        s = s[:-1]
        try:
            return float(s) / 100.0
        except ValueError:
            return None
    try:
        v = float(s)
        return v if v <= 1.5 else v / 100.0
    except ValueError:
        return None

def _is_truthy_str(x: Any) -> bool:
    return _to_str(x) != ""

def _contains_ci(hay: str, needle: str) -> bool:
    return needle.lower() in hay.lower()

def _norm_categoria(cvm: str) -> str:
    s = _to_str(cvm)
    return "Internacional" if s.lower() == "cambial" else s

def _norm_risco(lbl: str) -> str:
    s = _to_str(lbl)
    s_low = s.lower()
    if s_low == "muito baixo":
        return "Baixo"
    if s_low == "muito alto":
        return "Alto"
    return s

NAO_REGEX = re.compile(r"^\s*(nao|não)\s*(ha|há|possui)\.?\s*$", re.IGNORECASE)

def _clean_perf_fee(x: Any) -> str:
    s = _to_str(x)
    if s == "":
        return ""
    if s.strip() == "0":
        return ""
    if NAO_REGEX.match(s):
        return ""
    return s

# --------------- Core ---------------

def fetch_json(url: str) -> Optional[Dict[str, Any]]:
    try:
        r = requests.get(url, timeout=HTTP_TIMEOUT)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        print(f"[ERRO] Falha ao baixar {url}: {e}", file=sys.stderr)
        return None

def normalize_fundo(payload: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    pc = (payload.get("result") or {}).get("pageContext") or {}
    fd = pc.get("filterData") or {}
    days = fd.get("daysToRescue") or {}
    risk = fd.get("risk") or {}
    adm = fd.get("adminFee") or {}
    perf = fd.get("performanceFee") or {}
    prof = fd.get("profileData") or {}

    # filtros
    status = _to_str(pc.get("status"))
    if not _contains_ci(status, "ativo"):
        return None
    inv_prof = _to_str(prof.get("investorProfile"))
    if inv_prof.lower() != "investidores em geral".lower():
        return None
    if not _is_truthy_str(fd.get("in12Months")):
        return None
    if not _is_truthy_str(fd.get("profitYear")):
        return None

    # campos normalizados
    nome = _to_str(pc.get("nome"))
    categoria = _norm_categoria(_to_str(fd.get("cvmClassification")))
    aplic_min = _to_float(fd.get("initialApplication"))
    taxa_adm = _percent_to_decimal(adm.get("current"))
    cot_res = ""
    liqu_res = _to_str(days.get("rescueValue"))
    risco = _norm_risco(_to_str(risk.get("label")))
    rent_mes = _percent_to_decimal(fd.get("profitMonth"))   # corrigido para decimal
    rent_ano = _percent_to_decimal(fd.get("profitYear"))
    rent_12m = _percent_to_decimal(fd.get("in12Months"))
    perf_prev = _clean_perf_fee(perf.get("previous"))

    return {
        "nome": nome,
        "categoria": categoria,
        "aplic_min": aplic_min,
        "taxa_adm": taxa_adm,
        "cot_res": cot_res,
        "liqu_res": liqu_res,
        "risco": risco,
        "rent_mes": rent_mes,
        "rent_ano": rent_ano,
        "rent_12m": rent_12m,
        "performanceFee_previous": perf_prev,
    }

def read_endpoints(file_path: Path) -> List[str]:
    lines = []
    for line in file_path.read_text(encoding="utf-8").splitlines():
        l = line.strip()
        if not l or l.startswith("#"):
            continue
        lines.append(l)
    return lines

PREFIXO_ANONIMO = "F_2_"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--requests", required=True, help="Caminho para requests_fonte_2.txt")
    ap.add_argument("--outdir", required=True, help="Diretório de saída")
    args = ap.parse_args()

    req_file = Path(args.requests).resolve()
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    csv_path = outdir / "fundos_fonte_2.csv"

    endpoints = read_endpoints(req_file)
    rows: List[Dict[str, Any]] = []

    for url in endpoints:
        payload = fetch_json(url)
        if not payload:
            continue
        try:
            row = normalize_fundo(payload)
            if row is not None:
                rows.append(row)
        except Exception as e:
            print(f"[WARN] Erro ao processar {url}: {e}", file=sys.stderr)

    # ========== ANONIMIZAÇÃO ==========
    # Substituir nomes de fundos por IDs anônimos
    nome_map = {}
    for i, row in enumerate(rows, start=1):
        nome_original = row.get("nome", "")
        if nome_original and nome_original not in nome_map:
            nome_map[nome_original] = f"{PREFIXO_ANONIMO}{len(nome_map)+1:04d}"
        if nome_original:
            row["nome"] = nome_map[nome_original]
    print(f"[OK] {len(nome_map)} fundos anonimizados")
    # ==================================

    with open(csv_path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=CSV_COLUMNS)
        writer.writeheader()
        for r in rows:
            writer.writerow({k: ("" if r.get(k) is None else r.get(k)) for k in CSV_COLUMNS})

    print(f"[OK] Arquivo gerado: {csv_path}")
    print(f"[OK] Registros: {len(rows)}")

if __name__ == "__main__":
    main()
