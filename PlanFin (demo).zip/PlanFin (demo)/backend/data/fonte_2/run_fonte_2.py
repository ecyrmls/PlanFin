#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
run_fonte_2.py
Fluxo de coleta de fundos da Fonte 2:
1) Descobre a raiz do diretório fonte_2
2) Garante pasta do dia (TZ=America/Sao_Paulo): .../fonte_2/YYYY-MM-DD
3) Remove pastas antigas
4) Descriptografa requests.enc e chama parse_fonte_2.py
"""

from __future__ import annotations
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from datetime import datetime, date

try:
    from zoneinfo import ZoneInfo
except Exception:
    ZoneInfo = None

# Adicionar backend ao path para importar crypto_utils
SCRIPT_DIR = Path(__file__).resolve().parent
BACKEND_DIR = SCRIPT_DIR.parent.parent
sys.path.insert(0, str(BACKEND_DIR))

try:
    from crypto_utils import descriptografar_arquivo
    HAS_CRYPTO = True
except ImportError:
    HAS_CRYPTO = False

SENHA = os.environ.get("PLANFIN_SENHA")
if not SENHA:
    print("[AVISO] PLANFIN_SENHA não definida. Configure nas variáveis de ambiente.")
    SENHA = None

DATE_DIR_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")

def today_sp_iso() -> str:
    if ZoneInfo is None:
        return date.today().isoformat()
    return datetime.now(ZoneInfo("America/Sao_Paulo")).date().isoformat()

def prune_old_date_dirs(root: Path, keep_name: str) -> None:
    if not root.exists():
        return
    for child in root.iterdir():
        if child.is_dir() and child.name != keep_name and DATE_DIR_RE.match(child.name):
            try:
                shutil.rmtree(child)
                print(f"[RUN] Removida pasta antiga: {child}")
            except Exception as e:
                print(f"[WARN] Falha ao remover {child}: {e}", file=sys.stderr)

def assert_file(path: Path, label: str) -> None:
    if not path.exists():
        print(f"[ERRO] {label} não encontrado: {path}", file=sys.stderr)
        sys.exit(127)

def main():
    fonte2_root = SCRIPT_DIR
    
    # Arquivos de requests (criptografado ou não)
    requests_enc = fonte2_root / "requests.enc"
    requests_txt = fonte2_root / "requests_fonte_2.txt"
    
    parser_path = fonte2_root / "parse_fonte_2.py"

    print(f"[RUN] Iniciando rotina Fonte 2. Diretório base: {fonte2_root}")
    today = today_sp_iso()
    print(f"[RUN] Data de execução (TZ São Paulo): {today}")

    outdir = fonte2_root / today
    outdir.mkdir(parents=True, exist_ok=True)
    print(f"[RUN] Pasta do dia garantida: {outdir}")

    prune_old_date_dirs(fonte2_root, today)

    assert_file(parser_path, "Script de parsing (parse_fonte_2.py)")
    
    # Determinar arquivo de requests a usar
    requests_file = None
    temp_requests = None
    
    if HAS_CRYPTO and requests_enc.exists() and SENHA:
        print(f"[RUN] Descriptografando requests.enc...")
        try:
            conteudo = descriptografar_arquivo(requests_enc, SENHA)
            # Criar arquivo temporário com as URLs
            temp_requests = tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False, encoding='utf-8')
            temp_requests.write(conteudo)
            temp_requests.close()
            requests_file = Path(temp_requests.name)
            print(f"[OK] URLs descriptografadas para arquivo temporário")
        except Exception as e:
            print(f"[ERRO] Falha ao descriptografar: {e}")
            print("[INFO] Verifique se a senha está correta (PLANFIN_SENHA)")
            sys.exit(1)
    elif requests_txt.exists():
        print(f"[RUN] Usando arquivo de requests não criptografado: {requests_txt}")
        requests_file = requests_txt
    else:
        print(f"[ERRO] Nenhum arquivo de requests encontrado:")
        print(f"  - {requests_enc}")
        print(f"  - {requests_txt}")
        sys.exit(1)

    try:
        cmd = [
            sys.executable,
            str(parser_path),
            "--requests", str(requests_file),
            "--outdir", str(outdir),
        ]
        print(f"[RUN] Executando parser...")
        proc = subprocess.run(cmd, cwd=parser_path.parent)
        if proc.returncode != 0:
            print(f"[ERRO] Parser retornou código {proc.returncode}. Interrompendo.", file=sys.stderr)
            sys.exit(proc.returncode)
    finally:
        # Limpar arquivo temporário
        if temp_requests and Path(temp_requests.name).exists():
            Path(temp_requests.name).unlink()

    print("[OK] Rotina Fonte 2 finalizada com sucesso.")
    print(f"[OK] CSV final: {outdir / 'fundos_fonte_2.csv'}")

if __name__ == "__main__":
    main()
