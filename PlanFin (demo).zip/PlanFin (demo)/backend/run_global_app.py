
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations
import argparse, concurrent.futures as cf, csv, hashlib, json, os, subprocess, sys, time, re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional, Tuple
try:
    from zoneinfo import ZoneInfo
except Exception:
    ZoneInfo = None

TZ_NAME = os.environ.get("PLANFIN_TZ", "America/Sao_Paulo")
BASE_DIR = Path(os.environ.get("PLANFIN_BASE_DIR", "/app/data")).resolve()
RESPOSTAS_DIR = BASE_DIR / "respostas_questionario"
FONTE1_DIR    = BASE_DIR / "fonte_1"
FONTE2_DIR  = BASE_DIR / "fonte_2"
AGREGADOR_DIR   = BASE_DIR / "agregador_rf"
YF_DIR     = BASE_DIR / "yfinance"
ANALISE_DIR = BASE_DIR / "analise"
RUN_ANALISE_CMD = os.environ.get(
    "PLANFIN_RUN_ANALISE",
    "python -m backend.analise.reporter"
)

def session_dir(session_id: str) -> Path: return (ANALISE_DIR / "session" / session_id)

RUN_FONTE1_CMD   = os.environ.get("PLANFIN_RUN_FONTE1",   "python /app/data/fonte_1/run_fonte_1.py")
RUN_FONTE2_CMD = os.environ.get("PLANFIN_RUN_FONTE2", "python /app/data/fonte_2/run_fonte_2.py")
RUN_AGREGADOR_CMD  = os.environ.get("PLANFIN_RUN_AGREGADOR",  "python /app/data/agregador_rf/run_agregador.py")
RUN_YF_CMD    = os.environ.get("PLANFIN_RUN_YF",    "python /app/data/yfinance/run_yfinance.py")
AGREGADOR_REQUESTS_DIR = Path(os.environ.get("PLANFIN_AGREGADOR_REQUESTS_DIR", str(AGREGADOR_DIR))).resolve()

def now_brt() -> datetime:
    if ZoneInfo is None: return datetime.utcnow()
    return datetime.now(ZoneInfo(TZ_NAME))
def today_str_brt() -> str: return now_brt().strftime("%Y-%m-%d")

def file_sha256(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""): h.update(chunk)
    return h.hexdigest()

def csv_has_rows(csv_path: Path) -> bool:
    try:
        with csv_path.open("r", encoding="utf-8") as f:
            import csv as _csv
            reader = _csv.reader(f); header = next(reader, None); first = next(reader, None)
            return bool(header) and (first is not None)
    except Exception: return False

def find_oldest_valid_csv(dir_day: Path) -> Optional[Path]:
    if not dir_day.exists(): return None
    candidates = [p for p in dir_day.glob("*.csv") if p.is_file()]
    valid = [p for p in candidates if csv_has_rows(p)]
    if not valid: return None
    valid.sort(key=lambda p: p.stat().st_ctime)
    return valid[0]

def find_oldest_valid_csv_recursive(dir_path: Path) -> Optional[Path]:
    if not dir_path.exists():
        return None
    candidates = [p for p in dir_path.rglob("*.csv") if p.is_file()]
    valid = [p for p in candidates if csv_has_rows(p)]
    if not valid:
        return None
    valid.sort(key=lambda p: p.stat().st_ctime)
    return valid[0]

def ensure_dir(p: Path) -> None: p.mkdir(parents=True, exist_ok=True)

def run_shell(cmd: str, env: Optional[Dict[str, str]] = None) -> Tuple[int, str]:
    try:
        proc = subprocess.run(cmd, shell=True, check=False, capture_output=True, text=True, env=env or os.environ.copy())
        out = (proc.stdout or "") + (proc.stderr or "")
        return proc.returncode, out.strip()
    except Exception as e:
        return 1, f"[run_shell] exception: {e}"

@dataclass
class TaskResult:
    name: str; status: str; detail: str; path: Optional[str] = None; extra: Optional[Dict] = None

def task_generic(name: str, day_dir: Path, cmd: str) -> TaskResult:
    ensure_dir(day_dir)
    # Primeiro: tentar reutilizar arquivo do dia atual
    reused = find_oldest_valid_csv(day_dir)
    if reused: return TaskResult(name=name, status="reused", detail="reutilizado arquivo válido do dia", path=str(reused))
    # Segundo: tentar coletar novos dados
    rc, out = run_shell(cmd)
    if rc == 0:
        produced = find_oldest_valid_csv(day_dir)
        if produced: return TaskResult(name=name, status="ok", detail="coleta executada", path=str(produced))
    # Terceiro: FALLBACK - procurar em dias anteriores
    base_dir = day_dir.parent
    fallback = find_latest_valid_csv_anyday(base_dir)
    if fallback:
        return TaskResult(name=name, status="reused", detail=f"fallback: usando dados de {fallback.parent.name}", path=str(fallback))
    # Falhou completamente
    return TaskResult(name=name, status="erro", detail=f"falha ao executar e sem fallback disponível: {out[:2000] if 'out' in dir() else 'N/A'}", path=str(day_dir))

def task_agregador(day_dir: Path, answers_json: Path) -> TaskResult:
    name = "agregador_rf"; ensure_dir(day_dir)
    try: answers = json.loads(answers_json.read_text(encoding="utf-8"))
    except Exception as e: return TaskResult(name=name, status="erro", detail=f"não foi possível ler respostas JSON: {e}")
    period = answers.get("periodoSimulacaoMeses", None)
    if not isinstance(period, int) or period <= 0: return TaskResult(name=name, status="erro", detail="periodoSimulacaoMeses inválido/ausente")
    period_suffix = f"{period}m"
    period_dir = day_dir / period_suffix
    ensure_dir(period_dir)
    
    # Primeiro: tentar reutilizar arquivo do dia atual
    reused = find_oldest_valid_csv_recursive(period_dir)
    if reused: return TaskResult(name=name, status="reused", detail=f"reutilizado arquivo válido do dia ({period_suffix})", path=str(reused), extra={"periodo": period})
    
    # Segundo: verificar se arquivo de requests existe para tentar coletar
    req_file_enc = AGREGADOR_REQUESTS_DIR / f"requests_agregador_{period_suffix}.txt.enc"
    req_file_txt = AGREGADOR_REQUESTS_DIR / f"requests_agregador_{period_suffix}.txt"
    
    if req_file_enc.exists() or req_file_txt.exists():
        req_file = req_file_enc if req_file_enc.exists() else req_file_txt
        env = os.environ.copy(); env["PLANFIN_AGREGADOR_PERIOD_SUFFIX"] = period_suffix; env["PLANFIN_AGREGADOR_REQUESTS_FILE"] = str(req_file)
        rc, out = run_shell(RUN_AGREGADOR_CMD, env=env)
        if rc == 0:
            produced = find_oldest_valid_csv_recursive(period_dir)
            if produced: return TaskResult(name=name, status="ok", detail=f"coleta executada ({period_suffix})", path=str(produced), extra={"periodo": period})
    
    # Terceiro: FALLBACK - procurar em dias anteriores para o mesmo período
    base_dir = day_dir.parent
    subs = [d for d in base_dir.iterdir() if d.is_dir() and re.match(r'^\d{4}-\d{2}-\d{2}$', d.name)]
    subs.sort(key=lambda d: d.name, reverse=True)
    for day in subs:
        fallback_period_dir = day / period_suffix
        if fallback_period_dir.exists():
            fallback = find_oldest_valid_csv_recursive(fallback_period_dir)
            if fallback:
                return TaskResult(name=name, status="reused", detail=f"fallback: usando dados de {day.name}/{period_suffix}", path=str(fallback), extra={"periodo": period})
    
    # Falhou completamente
    return TaskResult(name=name, status="erro", detail=f"sem arquivo de requests e sem fallback disponível para {period_suffix}", path=str(day_dir), extra={"periodo": period})


def find_latest_valid_csv_anyday(base_dir: Path) -> Optional[Path]:
    """Procura CSV válido em qualquer subdiretório de data (YYYY-MM-DD), mais recente primeiro"""
    if not base_dir.exists(): return None
    subs = [d for d in base_dir.iterdir() if d.is_dir() and re.match(r'^\d{4}-\d{2}-\d{2}$', d.name)]
    if not subs: return None
    subs.sort(key=lambda d: d.name, reverse=True)
    for day in subs:
        cand = find_oldest_valid_csv(day)
        if cand: return cand
    return None

def find_latest_valid_csv_anyday_recursive(base_dir: Path) -> Optional[Path]:
    """Procura CSV válido recursivamente em qualquer subdiretório de data (YYYY-MM-DD), mais recente primeiro"""
    if not base_dir.exists(): return None
    subs = [d for d in base_dir.iterdir() if d.is_dir() and re.match(r'^\d{4}-\d{2}-\d{2}$', d.name)]
    if not subs: return None
    subs.sort(key=lambda d: d.name, reverse=True)
    for day in subs:
        cand = find_latest_valid_csv_recursive(day)
        if cand: return cand
    return None

def find_latest_valid_csv_recursive(dir_day: Path) -> Optional[Path]:
    if not dir_day.exists(): return None
    cands = [p for p in dir_day.rglob("*.csv") if p.is_file()]
    valid = [p for p in cands if csv_has_rows(p)]
    if not valid: return None
    valid.sort(key=lambda p: p.stat().st_ctime, reverse=True)
    return valid[0]

def list_valid_csvs_day(dir_day: Path):
    if not dir_day.exists(): 
        return []
    cands = [p for p in dir_day.glob("*.csv") if p.is_file()]
    valids = [p for p in cands if csv_has_rows(p)]
    valids.sort(key=lambda p: p.name)  # ordena por nome para estabilidade
    return valids

def build_inputs_manifest(date_str: str, results: Dict[str, TaskResult], answers_path: Path) -> Dict:
    # Usar os paths dos results (que já incluem fallbacks)
    fonte1_path = results.get("fonte_1", TaskResult("fonte_1","erro","")).path or ""
    fonte2_path = results.get("fonte_2", TaskResult("fonte_2","erro","")).path or ""
    agregador_path = results.get("agregador_rf", TaskResult("agregador_rf","erro","")).path or ""
    yfinance_path = results.get("yfinance", TaskResult("yfinance","erro","")).path or ""
    
    # Se path está vazio, tentar fallback global
    if not fonte1_path or not Path(fonte1_path).exists():
        fallback = find_latest_valid_csv_anyday(FONTE1_DIR)
        fonte1_path = str(fallback) if fallback else ""
    if not fonte2_path or not Path(fonte2_path).exists():
        fallback = find_latest_valid_csv_anyday(FONTE2_DIR)
        fonte2_path = str(fallback) if fallback else ""
    if not agregador_path or not Path(agregador_path).exists():
        fallback = find_latest_valid_csv_anyday_recursive(AGREGADOR_DIR)
        agregador_path = str(fallback) if fallback else ""
    if not yfinance_path or not Path(yfinance_path).exists():
        fallback = find_latest_valid_csv_anyday(YF_DIR)
        yfinance_path = str(fallback) if fallback else ""
    
    manifest = {
        "answersPath": str(answers_path),
        "date": date_str,
        "sources": {
            "fonte_1": fonte1_path,
            "fonte_2": fonte2_path,
            "agregador_rf": agregador_path,
            "yfinance": yfinance_path
        }
    }

    # === ADD: todos os CSVs do Yahoo - tentar dia atual, senão fallback ===
    yf_day = YF_DIR / date_str
    yf_list = list_valid_csvs_day(yf_day)
    if not yf_list:
        # Fallback: procurar em dias anteriores
        subs = [d for d in YF_DIR.iterdir() if d.is_dir() and re.match(r'^\d{4}-\d{2}-\d{2}$', d.name)]
        subs.sort(key=lambda d: d.name, reverse=True)
        for day in subs:
            yf_list = list_valid_csvs_day(day)
            if yf_list:
                yf_day = day
                break
    
    manifest["sources"]["yfinance_dir"] = str(yf_day)
    manifest["sources"]["yfinance_files"] = [str(p) for p in yf_list]

    return manifest

def write_status(session_id: str, date_str: str, phase: str, tasks: Dict[str, TaskResult]) -> None:
    sd = session_dir(session_id); ensure_dir(sd)
    data = {"session_id": session_id, "date": date_str, "phase": phase, "tasks_status": {k: v.status for k, v in tasks.items()}}
    (sd / "status.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

def now_log_header(session_id: str, answers_path: Path, date_str: str) -> None:
    print("========== PlanFin Orquestrador ==========")
    print(f"TZ.............: {TZ_NAME}")
    print(f"BASE_DIR.......: {BASE_DIR}")
    print(f"SESSION_ID.....: {session_id}")
    print(f"DATE (BRT).....: {date_str}")
    print(f"Answers Path...: {answers_path} (exists={answers_path.exists()})")
    print("Run commands...:")
    print(f"  FONTE1    -> {RUN_FONTE1_CMD}")
    print(f"  FONTE2    -> {RUN_FONTE2_CMD}")
    print(f"  AGREGADOR -> {RUN_AGREGADOR_CMD}")
    print(f"  YFINANCE  -> {RUN_YF_CMD}")
    print("==========================================")

def orchestrate(session_id: str, answers_path: Path, debounce_seconds: int = 2) -> int:
    time.sleep(max(0, debounce_seconds))
    if not answers_path.exists():
        print(f"[ERRO] JSON de respostas não encontrado: {answers_path}")
        return 1
    date_str = today_str_brt()
    now_log_header(session_id, answers_path, date_str)
    write_status(session_id, date_str, phase="RECEIVED", tasks={k: TaskResult(k, "skip", "") for k in ["fonte_1","fonte_2","agregador_rf","yfinance"]})
    day_dirs = {"fonte_1": FONTE1_DIR / date_str, "fonte_2": FONTE2_DIR / date_str, "agregador_rf": AGREGADOR_DIR / date_str, "yfinance": YF_DIR / date_str}
    write_status(session_id, date_str, phase="RUNNING", tasks={k: TaskResult(k, "skip", "") for k in day_dirs.keys()})
    results: Dict[str, TaskResult] = {}
    with cf.ThreadPoolExecutor(max_workers=4) as ex:
        futs = {
            "fonte_1": ex.submit(task_generic, "fonte_1", day_dirs["fonte_1"], RUN_FONTE1_CMD),
            "fonte_2": ex.submit(task_generic, "fonte_2", day_dirs["fonte_2"], RUN_FONTE2_CMD),
            "agregador_rf": ex.submit(task_agregador, day_dirs["agregador_rf"], answers_path),
            "yfinance": ex.submit(task_generic, "yfinance", day_dirs["yfinance"], RUN_YF_CMD),
        }
        for k, fut in futs.items():
            try: results[k] = fut.result()
            except Exception as e: results[k] = TaskResult(name=k, status="erro", detail=f"exceção: {e}")
    write_status(session_id, date_str, phase="AGGREGATING", tasks=results)
    agregador_fail = results["agregador_rf"].status == "erro"; yf_fail = results["yfinance"].status == "erro"
    if agregador_fail and yf_fail:
        write_status(session_id, date_str, phase="FAILED", tasks=results); print(_final_log(session_id, date_str, answers_path, results, all_ok=False)); return 1
    any_error = any(r.status == "erro" for r in results.values())
    phase = "PARTIAL_READY" if any_error else "READY_FOR_ANALYSIS"
    write_status(session_id, date_str, phase=phase, tasks=results)
    print(_final_log(session_id, date_str, answers_path, results, all_ok=(phase=='READY_FOR_ANALYSIS')))
    # --- Análise (regras -> seletor -> alocador -> comparacoes -> projecao -> reporter)
    # Política: rodar análise se pelo menos Agregador OU YFinance estiverem OK, e existir ao menos UMA corretora OK/reused.
    cond_y = results["agregador_rf"].status in ("ok","reused")
    cond_yf = results["yfinance"].status in ("ok","reused")
    cond_corretoras = any(results[k].status in ("ok","reused") for k in ("fonte_1","fonte_2"))

    if (cond_y or cond_yf) and cond_corretoras:
        print("[STEP] analise -> iniciando pipeline de análise")
        analise_res = run_analise(session_id, date_str, answers_path, results)
        print(f"[STEP] analise -> {analise_res.status.upper()} (out: {analise_res.path})")
        if analise_res.status == "erro":
            print("[DETAIL] analise ->")
            print(analise_res.detail)
        tasks_with_analise = dict(results); tasks_with_analise["analise"] = analise_res
        final_phase = "ANALISE_OK" if analise_res.status == "ok" else "ANALISE_ERR"
        write_status(session_id, date_str, phase=final_phase, tasks=tasks_with_analise)

    else:
        print("[STEP] analise -> SKIP (insumos insuficientes)")
        write_status(session_id, date_str, phase="SKIPPED_ANALISE", tasks=results)
    return 0

def _final_log(session_id: str, date_str: str, answers_path: Path, results: Dict[str, TaskResult], all_ok: bool) -> str:
    def okerr(name: str) -> str: return "OK" if results[name].status in ("ok","reused") else "ERRO"
    i_json = "OK" if answers_path.exists() else "ERRO"
    corretoras_ok = all(results[k].status in ("ok","reused") for k in ("fonte_1","fonte_2"))
    vi_all = "OK" if corretoras_ok else "ERRO"
    agregador = results["agregador_rf"]; agregador_tag = f"({agregador.extra['periodo']}m)" if agregador.extra and isinstance(agregador.extra.get("periodo"), int) else ""
    vii_line = f"{okerr('agregador_rf')}{agregador_tag}"
    ix_all = "OK" if all_ok else "ERRO"
    lines = []
    lines.append(f"[DATA_LOCAL={date_str} {TZ_NAME}] [SESSION_ID={session_id}] [JSON_HASH={file_sha256(answers_path) if answers_path.exists() else 'NA'}]")
    lines.append(f"i)   [resp_json]     {i_json}  (path: {answers_path})")
    lines.append(f"ii)  [fonte1_coleta]    {okerr('fonte_1')}  (path: {results['fonte_1'].path or (FONTE1_DIR / date_str)})")
    lines.append(f"iii) [fonte2_coleta]  {okerr('fonte_2')}(path: {results['fonte_2'].path or (FONTE2_DIR / date_str)})")
    lines.append(f"iv)  [todas_corretoras] {vi_all}")
    lines.append(f"v)   [agregador_coleta]   {vii_line} (path: {results['agregador_rf'].path or (AGREGADOR_DIR / date_str)})")
    lines.append(f"vi)  [yfinance]      {okerr('yfinance')} (path: {results['yfinance'].path or (YF_DIR / date_str)})")
    lines.append(f"vii) [processo_geral]{ix_all}")
    lines.append("—")
    lines.append(f"[PlanFin][SESSION={session_id}][DATE={date_str}]"
                 f"[json={i_json}]"
                 f"[fonte1={okerr('fonte_1')}]"
                 f"[fonte2={okerr('fonte_2')}]"
                 f"[corretoras={vi_all}]"
                 f"[agregador={vii_line}]"
                 f"[yfinance={okerr('yfinance')}]"
                 f"[all={'OK' if all_ok else 'ERRO'}]")
    return "\n".join(lines)

def run_analise(session_id: str, date_str: str, answers_path: Path, results: Dict[str, TaskResult]) -> TaskResult:
    ensure_dir(session_dir(session_id))
    ensure_dir(ANALISE_DIR / date_str / session_id)

    manifest = build_inputs_manifest(date_str, results, answers_path)
    manifest_path = session_dir(session_id) / "analise_inputs.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    out_json = ANALISE_DIR / date_str / session_id / "resultado.json"

    env = os.environ.copy()
    env.setdefault("PLANFIN_TZ", TZ_NAME)
    env["PYTHONPATH"] = (env.get("PYTHONPATH", "") + (":" if env.get("PYTHONPATH") else "") + "/app")

    cmd = (
        f'{RUN_ANALISE_CMD} '
        f'--answers "{answers_path}" '
        f'--inputs-manifest "{manifest_path}" '
        f'--out "{out_json}"'
    )

    rc, out = run_shell(cmd, env=env)
    detail = f"analise rc={rc}\n{out[:4000]}"
    status = "ok" if (rc == 0 and out_json.exists() and out_json.stat().st_size > 0) else "erro"
    return TaskResult(name="analise", status=status, detail=detail, path=str(out_json))

def parse_args(argv=None):
    ap = argparse.ArgumentParser(description="PlanFin Orquestrador (run_global_app.py)")
    ap.add_argument("--session-id", required=True); ap.add_argument("--answers-path", required=True); ap.add_argument("--debounce-seconds", type=int, default=2)
    return ap.parse_args(argv)
def main(argv=None) -> int:
    args = parse_args(argv); sess = args.session_id.strip(); answers = Path(args.answers_path).resolve()
    ensure_dir(session_dir(sess)); return orchestrate(session_id=sess, answers_path=answers, debounce_seconds=args.debounce_seconds)
if __name__ == "__main__": sys.exit(main())
