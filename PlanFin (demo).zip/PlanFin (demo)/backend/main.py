
# -*- coding: utf-8 -*-
"""
PlanFin Backend — main.py (versão tolerante ao payload) + alias /stage-a/start
"""
import os, json, uuid, logging, subprocess
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel

logging.basicConfig(level=os.environ.get("LOG_LEVEL", "INFO"), format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("planfin-backend")

PLANFIN_SAVE_DIR = Path(os.environ.get("PLANFIN_SAVE_DIR", "/app/data/respostas_questionario")).resolve()
PLANFIN_BASE_DIR = Path(os.environ.get("PLANFIN_BASE_DIR", "/app/data")).resolve()
PLANFIN_TZ = os.environ.get("PLANFIN_TZ", "America/Sao_Paulo")
ORCHESTRATOR_PRIMARY = Path("/app/run_global_app.py")
ORCHESTRATOR_FALLBACK = Path("/app/run_global.py")
FRONTEND_ORIGIN = os.environ.get("FRONTEND_ORIGIN", "http://localhost:5173")

app = FastAPI(title="PlanFin Backend", version="1.1.1")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[FRONTEND_ORIGIN, "http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class SubmitRequest(BaseModel):
    session_id: Optional[str] = None
    payload: Dict[str, Any]

class SubmitResponse(BaseModel):
    session_id: str
    filename: str
    saved_path: str
    orchestrator_rc: int
    orchestrator_used: str

def ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)

def save_answers_json(session_id: str, data: Dict[str, Any]) -> Path:
    ensure_dir(PLANFIN_SAVE_DIR)
    ts = datetime.utcnow().strftime("%Y%m%d-%H%M%S")
    filename = f"{session_id}_{ts}.json"
    path = PLANFIN_SAVE_DIR / filename
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return path

def choose_orchestrator() -> Path:
    if ORCHESTRATOR_PRIMARY.exists(): return ORCHESTRATOR_PRIMARY
    if ORCHESTRATOR_FALLBACK.exists(): return ORCHESTRATOR_FALLBACK
    return ORCHESTRATOR_PRIMARY

def disparar_orquestracao(session_id: str, answers_path: Path, debounce_seconds: int = 2) -> int:
    orch = choose_orchestrator()
    cmd = ["python", str(orch), "--session-id", session_id, "--answers-path", str(answers_path), "--debounce-seconds", str(debounce_seconds)]
    log.info("===== Disparando orquestração =====")
    log.info("Orchestrator.....: %s (exists=%s)", orch, orch.exists())
    log.info("Session ID.......: %s", session_id)
    log.info("Answers Path.....: %s (exists=%s)", answers_path, answers_path.exists())
    log.info("CMD..............: %s", " ".join(cmd))
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
    except Exception as e:
        log.exception("Falha ao executar orquestrador: %s", e)
        return 1
    if proc.stdout:
        log.info("---- orchestrator stdout ----\n%s\n-----------------------------", proc.stdout.strip())
    if proc.stderr:
        log.warning("---- orchestrator stderr ----\n%s\n-----------------------------", proc.stderr.strip())
    log.info("Return code do orquestrador: %s", proc.returncode)
    return int(proc.returncode)

@app.get("/health")
def health():
    try:
        ensure_dir(PLANFIN_SAVE_DIR); writable = os.access(PLANFIN_SAVE_DIR, os.W_OK)
    except Exception as e:
        writable = False; log.error("Erro ao testar escrita em %s: %s", PLANFIN_SAVE_DIR, e)
    return {"status": "ok", "save_dir": str(PLANFIN_SAVE_DIR), "save_dir_exists": PLANFIN_SAVE_DIR.exists(), "save_dir_writable": writable, "tz": PLANFIN_TZ}

@app.post("/questionario/submit", response_model=SubmitResponse)
async def submit(request: Request):
    log.info("Headers recebidos: %s", dict(request.headers))
    try:
        body = await request.json()
    except Exception as e:
        log.exception("Body não é JSON válido: %s", e); raise HTTPException(status_code=400, detail="Body deve ser JSON; verifique Content-Type: application/json")
    session_id = (body.get("session_id") or "").strip() if isinstance(body, dict) else ""
    if not session_id: session_id = uuid.uuid4().hex
    if isinstance(body, dict) and "payload" in body and isinstance(body["payload"], dict):
        payload = body["payload"]
    elif isinstance(body, dict):
        payload = body
    else:
        raise HTTPException(status_code=400, detail="Formato inválido: JSON deve ser objeto/dicionário.")
    if "periodoSimulacaoMeses" in payload: log.info("periodoSimulacaoMeses=%s", payload.get("periodoSimulacaoMeses"))
    try:
        saved_path = save_answers_json(session_id, payload)
    except Exception as e:
        log.exception("Erro ao salvar JSON de respostas: %s", e); raise HTTPException(status_code=500, detail=f"Erro ao salvar JSON: {e}")
    rc = disparar_orquestracao(session_id=session_id, answers_path=saved_path, debounce_seconds=2)
    return SubmitResponse(session_id=session_id, filename=saved_path.name, saved_path=str(saved_path), orchestrator_rc=rc, orchestrator_used=str(choose_orchestrator()))

# Alias para compatibilidade com o front atual
@app.post("/stage-a/start")
async def stage_a_start(request: Request):
    return await submit(request)

# Rota para servir o resultado da análise
@app.get("/analise/{date}/{session_id}/resultado.json")
async def get_resultado(date: str, session_id: str):
    resultado_path = PLANFIN_BASE_DIR / "analise" / date / session_id / "resultado.json"
    log.info("Buscando resultado em: %s (exists=%s)", resultado_path, resultado_path.exists())
    if not resultado_path.exists():
        raise HTTPException(status_code=404, detail="Resultado não encontrado")
    try:
        content = json.loads(resultado_path.read_text(encoding="utf-8"))
        return JSONResponse(content=content)
    except Exception as e:
        log.exception("Erro ao ler resultado: %s", e)
        raise HTTPException(status_code=500, detail=f"Erro ao ler resultado: {e}")

if __name__ == "__main__":
    import uvicorn
    log.info("Iniciando PlanFin Backend")
    log.info("PLANFIN_SAVE_DIR=%s (exists=%s)", PLANFIN_SAVE_DIR, PLANFIN_SAVE_DIR.exists())
    ensure_dir(PLANFIN_SAVE_DIR)
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=False, workers=1)
