import { useParams } from "react-router-dom";
import { useSessionResults } from "../hooks/useSessionResults";
import { SummaryCards } from "../components/results/SummaryCards";
import { BucketPie } from "../components/results/BucketPie";
import { AssetPie } from "../components/results/AssetPie";
import { LifeLineChart } from "../components/results/LifeLineChart";
import { DisclaimerFooter } from "../components/results/DisclaimerFooter";
import { Card } from "../components/ui/card";

export function SessionResultPage() {
  const { date, sessionId } = useParams();
  const { data, status, error } = useSessionResults(date, sessionId, {
    poll: true,
    intervalMs: 800,
    timeoutMs: 60000,
  });

  if (status === "loading") return <div className="p-4 w-full">Carregando…</div>;
  if (status === "waiting") return <div className="p-4 w-full">Preparando análise…</div>;
  if (status === "error" || !data)
    return <div className="p-4 w-full">Erro ao carregar resultado. {error ? `(${error})` : ""}</div>;

  return (
    <div className="p-4 w-full max-w-none space-y-6">
      <SummaryCards assets={data.byAsset} />

      <Card className="p-4 w-full">
        <h2 className="text-lg font-bold mb-2">Distribuição por Classe</h2>
        <BucketPie data={data.byBucket} />
      </Card>

      <Card className="p-4 w-full">
        <h2 className="text-lg font-bold mb-2">Distribuição por Ativo</h2>
        <AssetPie assets={data.byAsset} />
      </Card>

      <Card className="p-4 w-full">
        <h2 className="text-lg font-bold mb-2">Linha da Vida</h2>
        <LifeLineChart lifeLine={data.lifeLine} />
      </Card>

      <DisclaimerFooter />
    </div>
  );
}
