import { useEffect, useRef, useState } from "react";

export function useSessionResults(
  date,
  sessionId,
  { poll = true, intervalMs = 800, timeoutMs = 60000 } = {}
) {
  const [data, setData] = useState(null);
  const [status, setStatus] = useState("loading"); // 'loading' | 'waiting' | 'ready' | 'error'
  const [error, setError] = useState(null);
  const timerRef = useRef(null);
  const startRef = useRef(null);

  useEffect(() => {
    let cancelled = false;

    const PUBLIC_URL = `/data/analise/${date}/${sessionId}/resultado.json`;
    const API =
      (import.meta.env && (import.meta.env.VITE_API_BASE_URL || import.meta.env.VITE_API_URL)) ||
      null;
    const API_URL = API ? `${API}/analise/${date}/${sessionId}/resultado.json` : null;

    async function tryFetch(url) {
      const res = await fetch(url, { cache: "no-store" });
      if (!res.ok) throw new Error(String(res.status || "fetch_error"));
      const ct = res.headers.get("content-type") || "";
      if (!ct.includes("application/json")) throw new Error("not_json_yet");
      return res.json();
    }

    const fetchOnce = async () => {
      try {
        try {
          const json = await tryFetch(PUBLIC_URL);
          if (cancelled) return false;
          setData(json);
          setStatus("ready");
          setError(null);
          return true;
        } catch (e1) {
          if (API_URL) {
            const json = await tryFetch(API_URL);
            if (cancelled) return false;
            setData(json);
            setStatus("ready");
            setError(null);
            return true;
          }
          throw e1;
        }
      } catch (e) {
        if (cancelled) return false;
        if (String(e.message).includes("404") || String(e.message).includes("not_json_yet")) {
          setError(null);
          return false;
        }
        setError(e.message || "fetch_error");
        return false;
      }
    };

    const startPolling = async () => {
      setStatus("loading");
      setData(null);
      setError(null);
      startRef.current = Date.now();

      const ok = await fetchOnce();
      if (ok || !poll) return;

      setStatus("waiting");
      const tick = async () => {
        if (cancelled) return;
        if (Date.now() - startRef.current > timeoutMs) {
          setStatus("error");
          return;
        }
        const ok2 = await fetchOnce();
        if (!ok2) {
          timerRef.current = setTimeout(tick, intervalMs);
        }
      };
      timerRef.current = setTimeout(tick, intervalMs);
    };

    startPolling();

    return () => {
      cancelled = true;
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [date, sessionId, poll, intervalMs, timeoutMs]);

  return { data, status, error };
}
