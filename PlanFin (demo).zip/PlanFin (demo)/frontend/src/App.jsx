import { BrowserRouter as Router, Routes, Route, useNavigate } from "react-router-dom";
import { useEffect } from "react";
import { SessionResultPage } from "./pages/SessionResultPage";
import Questionario from "./components/questionario/questionario";

function Welcome() {
  const navigate = useNavigate();

  useEffect(() => {
    const t = setTimeout(() => navigate("/questionario"), 3000);
    return () => clearTimeout(t);
  }, [navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="max-w-xl text-center">
        <h1 className="text-2xl font-bold mb-2">Bem-vindo ao PlanFin</h1>
        <p className="text-sm text-gray-500 mb-6">
          Você será redirecionado para o questionário em poucos segundos. Se preferir, avance agora.
        </p>
        <button
          className="px-4 py-2 rounded-2xl bg-blue-600 text-white hover:bg-blue-500 transition"
          onClick={() => navigate("/questionario")}
        >
          Continuar
        </button>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Welcome />} />
        <Route path="/questionario" element={<Questionario />} />
        <Route path="/resultado/:date/:sessionId" element={<SessionResultPage />} />
        <Route path="*" element={<Welcome />} />
      </Routes>
    </Router>
  );
}
