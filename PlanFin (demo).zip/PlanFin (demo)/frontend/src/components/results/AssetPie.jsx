import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer, LabelList } from "recharts";
import { normalizeAssets } from "../../lib/result-normalize";

const CLASS_COLOR = { RF: "#4ade80", MM: "#facc15", ACOES: "#60a5fa" };
const OTHERS_COLOR = "#9ca3af";

export function AssetPie({ assets }) {
  const normAssets = normalizeAssets(assets);
  const sorted = [...normAssets].sort((a, b) => b.weight - a.weight);
  const top = sorted.slice(0, 10);
  const others = sorted.slice(10);
  if (others.length > 0) {
    top.push({
      label: "Outros",
      class: "OUTROS",
      weight: others.reduce((acc, a) => acc + a.weight, 0),
      rent_12m: 0,
    });
  }

  return (
    <ResponsiveContainer width="100%" height={320}>
      <PieChart>
        <Pie data={top} dataKey="weight" nameKey="label" labelLine={false} innerRadius={60} outerRadius={100}>
          {top.map((entry, idx) => (
            <Cell
              key={idx}
              fill={entry.class in CLASS_COLOR ? CLASS_COLOR[entry.class] : OTHERS_COLOR}
              stroke="#ffffff"
              strokeWidth={1}
            />
          ))}
          <LabelList dataKey="weight" position="outside" formatter={(v) => `${(parseFloat(v) * 100).toFixed(2)}%`} />
        </Pie>
        <Tooltip formatter={(v) => `${(parseFloat(v) * 100).toFixed(2)}%`} />
        <Legend />
      </PieChart>
    </ResponsiveContainer>
  );
}
