import { useMemo, useState } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from "recharts";

export function LifeLineChart({ lifeLine }) {
  const [mode, setMode] = useState("percent"); // 'percent' | 'brl'

  const pct = lifeLine?.percent || {};
  const brl = lifeLine?.reais || {};

  // pega o maior comprimento disponível entre todas as séries
  const lengths = [
    (pct.carteira || []).length,
    (pct.selic || []).length,
    (pct.ipca || []).length,
    (pct.poupanca || []).length,
    (brl.carteira || []).length,
    (brl.selic || []).length,
    (brl.ipca || []).length,
    (brl.poupanca || []).length,
  ];
  const len = Math.max(0, ...lengths);

  // se backend não mandar years, gera [0..len-1]
  const years =
    Array.isArray(lifeLine?.years) && lifeLine.years.length
      ? lifeLine.years
      : Array.from({ length: len }, (_, i) => i);

  const EPS = 1e-6;
  const safe = (v) => (v > 0 ? v : EPS);

  const data = useMemo(() => {
    return years.map((year, idx) => ({
      year,
      // Percent (rebased em 100) — usa EPS para não quebrar log se vier 0
      carteiraPct: safe(Number(pct.carteira?.[idx] ?? 0) * 100),
      selicPct: safe(Number(pct.selic?.[idx] ?? 0) * 100),
      ipcaPct: safe(Number(pct.ipca?.[idx] ?? 0) * 100),
      poupancaPct: safe(Number(pct.poupanca?.[idx] ?? 0) * 100),
      // Reais — idem
      carteiraBRL: safe(Number(brl.carteira?.[idx] ?? 0)),
      selicBRL: safe(Number(brl.selic?.[idx] ?? 0)),
      ipcaBRL: safe(Number(brl.ipca?.[idx] ?? 0)),
      poupancaBRL: safe(Number(brl.poupanca?.[idx] ?? 0)),
    }));
  }, [years, pct, brl]);

  const hasPct = data.some(
    (d) => d.carteiraPct > EPS || d.selicPct > EPS || d.ipcaPct > EPS || d.poupancaPct > EPS
  );
  const hasAnyBRL = data.some(
    (d) => d.carteiraBRL > EPS || d.selicBRL > EPS || d.ipcaBRL > EPS || d.poupancaBRL > EPS
  );

  if (!len || !hasPct) {
    return (
      <div className="text-sm text-gray-500">
        Sem dados suficientes para a Linha da Vida.
      </div>
    );
  }

  const isPercent = mode === "percent";

  // Define as configurações das linhas baseado no modo
  const lineConfigs = isPercent
    ? [
        { dataKey: "carteiraPct", stroke: "#6366f1", name: "Carteira %" },
        { dataKey: "selicPct", stroke: "#16a34a", name: "Selic %" },
        { dataKey: "ipcaPct", stroke: "#f59e0b", name: "IPCA %" },
        { dataKey: "poupancaPct", stroke: "#e11d48", name: "Poupança %" },
      ]
    : [
        { dataKey: "carteiraBRL", stroke: "#6366f1", name: "Carteira R$" },
        { dataKey: "selicBRL", stroke: "#16a34a", name: "Selic R$" },
        { dataKey: "ipcaBRL", stroke: "#f59e0b", name: "IPCA R$" },
        { dataKey: "poupancaBRL", stroke: "#e11d48", name: "Poupança R$" },
      ];

  return (
    <div className="w-full">
      {/* Toggle */}
      <div className="mb-3 flex items-center gap-2">
        <button
          className={`px-3 py-1.5 rounded-2xl border ${isPercent ? "bg-blue-600 text-white border-blue-600" : "bg-transparent text-blue-700 border-blue-600"}`}
          onClick={() => setMode("percent")}
        >
          Porcentagens (%)
        </button>
        <button
          className={`px-3 py-1.5 rounded-2xl border ${!isPercent ? "bg-blue-600 text-white border-blue-600" : "bg-transparent text-blue-700 border-blue-600"} ${!hasAnyBRL ? "opacity-50 cursor-not-allowed" : ""}`}
          onClick={() => hasAnyBRL && setMode("brl")}
          disabled={!hasAnyBRL}
        >
          Reais (R$)
        </button>
        <span className="text-xs text-gray-500 ml-2">
          Eixo Y em escala logarítmica
        </span>
      </div>

      {/* Gráfico único com alternância */}
      <div className="w-full">
        <ResponsiveContainer width="100%" height={360}>
          <LineChart data={data}>
            <XAxis dataKey="year" />
            <YAxis scale="log" domain={["auto", "auto"]} />
            <Tooltip />
            <Legend />
            {lineConfigs.map((config) => (
              <Line
                key={config.dataKey}
                type="monotone"
                dataKey={config.dataKey}
                stroke={config.stroke}
                name={config.name}
                dot={false}
                strokeWidth={2}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
