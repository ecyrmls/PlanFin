import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { normalizeAssets, weightedAverage12m } from "../../lib/result-normalize";
import { fmtPercentBR } from "../../lib/format";

export function SummaryCards({ assets }) {
  const normAssets = normalizeAssets(assets);
  const avg12m = weightedAverage12m(normAssets);
  return (
    <div className="grid gap-4 md:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Rentabilidade Média 12m</CardTitle>
        </CardHeader>
        <CardContent>
          <span className="text-xl font-bold">{fmtPercentBR(avg12m)}</span>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Ativos</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="list-disc list-inside">
            {normAssets.map((a) => (
              <li key={a.label}>{a.label}</li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
