export function DisclaimerFooter() {
  return (
    <div className="mt-6 w-full">
      <div className="text-xs text-gray-600 space-y-1">
        <p>
          Rentabilidades passadas não são garantia de resultados futuros. Este material tem caráter
          exclusivamente informativo e não constitui oferta de compra ou de venda de quaisquer ativos.
        </p>
        <p>
          A decisão de investir deve considerar o perfil do investidor, seus objetivos, seu horizonte de investimento e sua tolerância a riscos.
        </p>
        <p>
          Consulte sempre um profissional de investimentos antes de tomar qualquer decisão.
        </p>
      </div>
    </div>
  );
}
