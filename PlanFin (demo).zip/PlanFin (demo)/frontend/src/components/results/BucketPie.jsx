import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer, LabelList } from "recharts";
import { bucketLabel } from "../../lib/result-normalize";

const BUCKET_COLORS = { RF: "#4ade80", MM: "#facc15", ACOES: "#60a5fa" };

export function BucketPie({ data }) {
  const order = ["RF", "MM", "ACOES"];
  const ordered = [...data].sort((a, b) => order.indexOf(a.bucket) - order.indexOf(b.bucket));

  return (
    <ResponsiveContainer width="100%" height={320}>
      <PieChart>
        <Pie data={ordered} dataKey="weight" nameKey="bucket" labelLine={false} innerRadius={60} outerRadius={100}>
          {ordered.map((entry, idx) => (
            <Cell key={idx} fill={BUCKET_COLORS[entry.bucket]} stroke="#ffffff" strokeWidth={1} />
          ))}
          <LabelList dataKey="weight" position="outside" formatter={(v) => `${(parseFloat(v) * 100).toFixed(2)}%`} />
        </Pie>
        <Tooltip formatter={(v) => `${(parseFloat(v) * 100).toFixed(2)}%`} />
        <Legend formatter={(val) => bucketLabel(val)} />
      </PieChart>
    </ResponsiveContainer>
  );
}
