// frontend/src/components/questionario/questionario.jsx
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import Secao1 from "./secao1_info";
import Secao2 from "./secao2_renda";
import Secao3 from "./secao3_investidor";
import Secao4 from "./secao4_planos";

const Questionario = ({ onComplete }) => {
  const navigate = useNavigate();
  const [secaoAtual, setSecaoAtual] = useState(1);
  const [respostas, setRespostas] = useState({});

  // Data YYYY-MM-DD em America/Sao_Paulo
  function dateStrSP() {
    const now = new Date();
    const fmt = new Intl.DateTimeFormat("pt-BR", {
      timeZone: "America/Sao_Paulo",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    });
    const [{ value: d }, , { value: m }, , { value: y }] = fmt.formatToParts(now);
    return `${y}-${m}-${d}`; // YYYY-MM-DD
  }

  const handleCompleteSecao1 = (r1) => {
    setRespostas((prev) => ({ ...prev, ...r1 }));
    setSecaoAtual(2);
  };

  const handleCompleteSecao2 = (r2) => {
    setRespostas((prev) => ({ ...prev, ...r2 }));
    setSecaoAtual(3);
  };

  const handleCompleteSecao3 = (r3) => {
    setRespostas((prev) => ({ ...prev, ...r3 }));
    setSecaoAtual(4);
  };

  const handleCompleteSecao4 = (r4) => {
    const consolidadas = { ...respostas, ...r4 };
    const session_id =
      typeof crypto !== "undefined" && crypto.randomUUID
        ? crypto.randomUUID()
        : String(Date.now());

    const payload = {
      session_id,
      timestamp: new Date().toISOString(),
      respostas: consolidadas,
    };

    const API =
      import.meta.env?.VITE_API_BASE_URL ||
      import.meta.env?.VITE_API_URL ||
      "http://localhost:8000";

    // 1) dispare o POST **sem aguardar** (não bloqueia o redirect)
    fetch(`${API}/stage-a/start`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        session_id: payload.session_id,
        respostas: payload.respostas,
        periodoSimulacaoMeses: payload.respostas?.periodoSimulacaoMeses ?? 1,
      }),
    })
      .then((res) => {
        if (!res.ok) {
          console.warn("Falha no POST /stage-a/start:", res.status, res.statusText);
          return null;
        }
        return res.json().catch(() => ({}));
      })
      .then((data) => {
        if (data?.saved_path) {
          console.log("Arquivo salvo no backend em:", data.saved_path);
        }
      })
      .catch((e) => {
        console.warn("Erro ao enviar ao backend (seguindo normalmente):", e);
      });

    // 2) onComplete (uma única vez)
    if (typeof onComplete === "function") {
      onComplete(consolidadas);
    }

    // 3) redireciona **imediatamente** — a página de resultados mostrará "Preparando análise..."
    const date = dateStrSP();
    navigate(`/resultado/${date}/${session_id}`);
  };

  return (
    <div className="p-4">
      {secaoAtual === 1 && <Secao1 onComplete={handleCompleteSecao1} />}
      {secaoAtual === 2 && <Secao2 onComplete={handleCompleteSecao2} />}
      {secaoAtual === 3 && <Secao3 onComplete={handleCompleteSecao3} />}
      {secaoAtual === 4 && <Secao4 onComplete={handleCompleteSecao4} />}
    </div>
  );
};

export default Questionario;
