// secao2_renda.jsx — versão com bonificações em camelCase
// Ajustes solicitados:
//  - "Anual(is)_valor"      -> valorBonificacaoAno   | checkbox: temBonificacaoAno
//  - "Semestral(is)_valor"  -> valorBonificacao6m    | checkbox: temBonificacao6m
//  - "Trimestral(is)_valor" -> valorBonificacao3m    | checkbox: temBonificacao3m

import React, { useState } from "react";

const Secao2 = ({ onComplete }) => {
  const [etapa, setEtapa] = useState(1);
  const [respostas, setRespostas] = useState({});

  const handleChange = (campo, valor) => {
    setRespostas((prev) => ({ ...prev, [campo]: valor }));
  };

  // [CFG] Bonificações (label para UI + chaves camelCase para dados)
  const bonusCfg = [
    { label: "Anual(is)", checkKey: "temBonificacaoAno", valorKey: "valorBonificacaoAno" },
    { label: "Semestral(is)", checkKey: "temBonificacao6m", valorKey: "valorBonificacao6m" },
    { label: "Trimestral(is)", checkKey: "temBonificacao3m", valorKey: "valorBonificacao3m" },
  ];

  // Validação enxuta para 2 etapas
  const podeAvancar = () => {
    switch (etapa) {
      case 1:
        return (
          respostas.rendaMensal !== undefined &&
          respostas.possuiRendaExtra !== undefined &&
          (respostas.possuiRendaExtra !== "Sim" || respostas.valorRendaExtra !== undefined)
        );
      case 2:
        return respostas.gastosFixos !== undefined && respostas.gastosVariaveis !== undefined;
      default:
        return true;
    }
  };

  const handleAvancar = () => {
    if (etapa < 2) {
      setEtapa(etapa + 1);
    } else {
      onComplete(respostas);
    }
  };

  const formatarParaReal = (valor, limite = 50000) => {
    if (valor === undefined || valor === null || valor === "") return "R$ 0";
    const num = Number(valor);
    if (Number.isNaN(num)) return "R$ 0";
    if (num >= limite) return `R$${limite.toLocaleString("pt-BR")} ou mais`;
    return num.toLocaleString("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 0 });
  };

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Seção 2: Renda e Patrimônio</h2>

      {etapa === 1 && (
        <div className="space-y-4">
          {/* 6. Renda mensal */}
          <div>
            <label className="block font-medium">6. Qual é a sua renda mensal aproximada?</label>
            <input
              type="range"
              min="0"
              max="50000"
              step="250"
              value={respostas.rendaMensal ?? 0}
              onChange={(e) => handleChange("rendaMensal", Math.min(Number(e.target.value), 50000))}
              className="w-full"
            />
            <input
              type="number"
              placeholder="Digite o valor em R$"
              className="mt-1 p-2 border rounded w-full"
              value={respostas.rendaMensal ?? ""}
              onChange={(e) => handleChange("rendaMensal", Math.min(Number(e.target.value), 50000))}
            />
            <div className="text-center">{formatarParaReal(respostas.rendaMensal)}</div>
          </div>

          {/* 7. Possui renda extra? */}
          <div>
            <label className="block font-medium">7. Você possui alguma renda extra?</label>
            <div className="mt-2 space-y-1">
              {["Sim", "Não", "Prefiro não responder"].map((opcao) => (
                <div key={opcao}>
                  <label className="inline-flex items-center">
                    <input
                      type="radio"
                      className="form-radio"
                      name="possuiRendaExtra"
                      value={opcao}
                      checked={respostas.possuiRendaExtra === opcao}
                      onChange={(e) => handleChange("possuiRendaExtra", e.target.value)}
                    />
                    <span className="ml-2">{opcao}</span>
                  </label>
                </div>
              ))}
            </div>
          </div>

          {respostas.possuiRendaExtra === "Sim" && (
            <>
              <div>
                <label className="block font-medium">Qual é o valor mensal aproximado dessa renda extra?</label>
                <input
                  type="range"
                  min="100"
                  max="250000"
                  step="100"
                  value={respostas.valorRendaExtra ?? 100}
                  onChange={(e) => handleChange("valorRendaExtra", Math.min(Number(e.target.value), 250000))}
                  className="w-full"
                />
                <input
                  type="number"
                  placeholder="Digite o valor em R$"
                  className="mt-1 p-2 border rounded w-full"
                  value={respostas.valorRendaExtra ?? ""}
                  onChange={(e) => handleChange("valorRendaExtra", Math.min(Number(e.target.value), 250000))}
                />
                <div className="text-center">{formatarParaReal(respostas.valorRendaExtra, 250000)}</div>
              </div>

              <div>
                <label className="block font-medium">Você recebe bonificações adicionais (trimestrais, semestrais, anuais etc.)?</label>
                <div className="mt-2 space-y-1">
                  {["Sim", "Não", "Prefiro não responder"].map((opcao) => (
                    <div key={opcao}>
                      <label className="inline-flex items-center">
                        <input
                          type="radio"
                          className="form-radio"
                          name="recebeBonificacoes"
                          value={opcao}
                          checked={respostas.recebeBonificacoes === opcao}
                          onChange={(e) => handleChange("recebeBonificacoes", e.target.value)}
                        />
                        <span className="ml-2">{opcao}</span>
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              {respostas.recebeBonificacoes === "Sim" && (
                <div>
                  <label className="block font-medium">Quais bonificações adicionais você recebe e aproximadamente em qual valor?</label>
                  <p className="text-sm text-gray-600">Caso receba mais de uma, considere o valor total.</p>

                  {bonusCfg.map(({ label, checkKey, valorKey }) => (
                    <div key={label} className="mt-2">
                      <label className="inline-flex items-center">
                        <input
                          type="checkbox"
                          className="form-checkbox"
                          checked={respostas[checkKey] || false}
                          onChange={(e) => handleChange(checkKey, e.target.checked)}
                        />
                        <span className="ml-2">{label}</span>
                      </label>

                      {respostas[checkKey] && (
                        <div className="mt-1">
                          <input
                            type="range"
                            min="1000"
                            max="500000"
                            step="1000"
                            value={respostas[valorKey] ?? 1000}
                            onChange={(e) => handleChange(valorKey, Math.min(Number(e.target.value), 500000))}
                            className="w-full"
                          />
                          <input
                            type="number"
                            placeholder="Digite o valor em R$"
                            className="mt-1 p-2 border rounded w-full"
                            value={respostas[valorKey] ?? ""}
                            onChange={(e) => handleChange(valorKey, Math.min(Number(e.target.value), 500000))}
                          />
                          <div className="text-center">{formatarParaReal(respostas[valorKey], 500000)}</div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      )}

      {etapa === 2 && (
        <div className="space-y-4">
          {/* 8. Gastos fixos mensais */}
          <div>
            <label className="block font-medium">8. Qual o valor estimado de seus gastos fixos mensais?</label>
            <p className="text-sm text-gray-600">Valores necessários e recorrentes: aluguel, contas, educação, condomínio, remédios, combustível etc.</p>
            <input
              type="range"
              min="100"
              max="100000"
              step="100"
              value={respostas.gastosFixos ?? 100}
              onChange={(e) => handleChange("gastosFixos", Math.min(Number(e.target.value), 100000))}
              className="w-full"
            />
            <input
              type="number"
              placeholder="Digite o valor em R$"
              className="mt-1 p-2 border rounded w-full"
              value={respostas.gastosFixos ?? ""}
              onChange={(e) => handleChange("gastosFixos", Math.min(Number(e.target.value), 100000))}
            />
            <div className="text-center">{formatarParaReal(respostas.gastosFixos, 100000)}</div>
          </div>

          {/* 9. Gastos variáveis mensais */}
          <div>
            <label className="block font-medium">9. Qual o valor estimado de seus gastos variáveis mensais?</label>
            <p className="text-sm text-gray-600">Valores dispensáveis: assinaturas, restaurantes, bares, viagens etc.</p>
            <input
              type="range"
              min="100"
              max="100000"
              step="100"
              value={respostas.gastosVariaveis ?? 100}
              onChange={(e) => handleChange("gastosVariaveis", Math.min(Number(e.target.value), 100000))}
              className="w-full"
            />
            <input
              type="number"
              placeholder="Digite o valor em R$"
              className="mt-1 p-2 border rounded w-full"
              value={respostas.gastosVariaveis ?? ""}
              onChange={(e) => handleChange("gastosVariaveis", Math.min(Number(e.target.value), 100000))}
            />
            <div className="text-center">{formatarParaReal(respostas.gastosVariaveis, 100000)}</div>
          </div>
        </div>
      )}

      <div className="mt-6">
        <button
          onClick={handleAvancar}
          disabled={!podeAvancar()}
          className="bg-blue-600 text-white px-4 py-2 rounded disabled:opacity-50"
        >
          {etapa < 2 ? "Continuar" : "Próxima seção"}
        </button>
      </div>
    </div>
  );
};

export default Secao2;
