import React, { useState } from "react";

const Secao1 = ({ onComplete }) => {
  const [etapa, setEtapa] = useState(1);
  const [respostas, setRespostas] = useState({});

  const handleChange = (campo, valor) => {
    setRespostas({ ...respostas, [campo]: valor });
  };

  const podeAvancar = () => {
    switch (etapa) {
      case 1:
        // Agora só exige faixa etária e estado civil
        return respostas.idadeFaixaEtaria && respostas.estadoCivil;
      case 2:
        // Apenas requer a escolha "Sim/Não/Prefiro não responder"
        return !!respostas.temDependentes;
      default:
        return true;
    }
  };

  const handleAvancar = () => {
    if (etapa < 4) {
      setEtapa(etapa + 1);
    } else {
      onComplete(respostas);
    }
  };

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Seção 1: Informações Pessoais e Familiares</h2>

      {etapa === 1 && (
        <div className="space-y-4">
          {/* 1. Faixa etária (MANTER) */}
          <div>
            <label className="block font-medium">1. Qual sua faixa etária?</label>
            <select
              className="mt-1 p-2 border rounded w-full"
              value={respostas.idadeFaixaEtaria || ""}
              onChange={(e) => handleChange("idadeFaixaEtaria", e.target.value)}
            >
              <option value="">Selecione</option>
              <option value="14-24">14 a 24 anos</option>
              <option value="25-34">25 a 34 anos</option>
              <option value="35-49">35 a 49 anos</option>
              <option value="50-64">50 a 64 anos</option>
              <option value="65-74">65 a 74 anos</option>
              <option value="75+">75 anos ou mais</option>
              <option value="prefiro_nao_responder">Prefiro não responder</option>
            </select>
          </div>

          {/* 2. Estado civil (MANTER) */}
          <div>
            <label className="block font-medium">2. Qual seu estado civil?</label>
            <div className="mt-1 space-y-1">
              {[
                "Solteiro(a)",
                "Casado(a)/União estável",
                "Separado(a)/Divorciado(a)",
                "Viúvo(a)",
                "Prefiro não responder"
              ].map((opcao) => (
                <div key={opcao}>
                  <label className="inline-flex items-center">
                    <input
                      type="radio"
                      className="form-radio"
                      name="estadoCivil"
                      value={opcao}
                      checked={respostas.estadoCivil === opcao}
                      onChange={(e) => handleChange("estadoCivil", e.target.value)}
                    />
                    <span className="ml-2">{opcao}</span>
                  </label>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {etapa === 2 && (
        <div className="space-y-4">
          {/* 3. Dependentes financeiros (MODIFICAR: somente Sim/Não/Prefiro não responder) */}
          <div>
            <label className="block font-medium">3. Você possui dependentes financeiros?</label>
            <div className="mt-2 space-y-1">
              {["Sim", "Não", "Prefiro não responder"].map((opcao) => (
                <div key={opcao}>
                  <label className="inline-flex items-center">
                    <input
                      type="radio"
                      className="form-radio"
                      name="temDependentes"
                      value={opcao}
                      checked={respostas.temDependentes === opcao}
                      onChange={(e) => handleChange("temDependentes", e.target.value)}
                    />
                    <span className="ml-2">{opcao}</span>
                  </label>
                </div>
              ))}
            </div>
          </div>
          {/* Observação: campos derivados (quantidade/idades/previsão) foram removidos */}
        </div>
      )}

      <div className="mt-6">
        <button
          onClick={handleAvancar}
          disabled={!podeAvancar()}
          className="bg-blue-600 text-white px-4 py-2 rounded disabled:opacity-50"
        >
          {etapa === 1 ? "Continuar" : "Próxima seção"}
        </button>
      </div>
    </div>
  );
};

export default Secao1;
