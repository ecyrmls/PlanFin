// secao4_planos.jsx — padronizada ao estilo das demais seções
import React, { useMemo, useState } from "react";

const Secao4 = ({ onComplete }) => {
  const [etapa, setEtapa] = useState(1);
  const [respostas, setRespostas] = useState({
    // default: 1 mês
    periodoSimulacaoMeses: 1,
    periodoSimulacaoRotulo: "1 mês",
    objetivoLongoPrazo: "",       // camelCase (ex.: "viverDeRendaPassiva")
    objetivoLongoPrazoRotulo: "", // rótulo apresentado ao usuário
    aposentadoriaRendaDesejadaMensal: 0,
  });
  const [aposentadoriaInput, setAposentadoriaInput] = useState("0"); // campo livre, normaliza no blur

  const handleChange = (campo, valor) => {
    setRespostas((prev) => ({ ...prev, [campo]: valor }));
  };

  const periodOptions = useMemo(
    () => [
      { label: "1 mês", months: 1 },
      { label: "3 meses", months: 3 },
      { label: "6 meses", months: 6 },
      { label: "9 meses", months: 9 },
      { label: "1 ano", months: 12 },
      { label: "2 anos", months: 24 },
      { label: "3 anos", months: 36 },
      { label: "4 anos", months: 48 },
      { label: "5 anos", months: 60 },
      { label: "10 anos", months: 120 },
      { label: "25 anos", months: 300 },
      { label: "50 anos", months: 600 },
    ],
    []
  );

  // encontra o index corrente a partir do valor em meses
  const periodIndex = Math.max(
    0,
    periodOptions.findIndex((p) => p.months === respostas.periodoSimulacaoMeses)
  );

  const showQ2 = respostas.periodoSimulacaoMeses > 12;
  const includeAposentadoria = respostas.periodoSimulacaoMeses >= 120;

  // objetivos com label (UI) e value camelCase (dados)
  const objetivosBase = [
    { label: "Viver de renda passiva", value: "viverDeRendaPassiva" },
    { label: "Maximização de rendimentos", value: "maximizacaoDeRendimentos" },
    { label: "Diversificação de rendimentos", value: "diversificacaoDeRendimentos" },
  ];
  const objetivos = includeAposentadoria
    ? [...objetivosBase, { label: "Garantir uma boa aposentadoria", value: "garantirBoaAposentadoria" }]
    : objetivosBase;

  // helpers
  const clamp = (num, min, max) => Math.max(min, Math.min(max, num));
  const roundToStep = (num, step) => Math.round(num / step) * step;
  const formatBRL = (n, cap = 50000) => {
    const val = Number(n) || 0;
    if (val >= cap) return "R$ 50.000,00 ou mais";
    return val.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
  };

  // handlers específicos
  const handlePeriodChange = (e) => {
    const idx = parseInt(e.target.value, 10);
    const opt = periodOptions[idx] ?? periodOptions[0];
    handleChange("periodoSimulacaoMeses", opt.months);
    handleChange("periodoSimulacaoRotulo", opt.label);

    // se encurtar o período, zera objetivo/aposentadoria para evitar lixo
    if (opt.months <= 12) {
      handleChange("objetivoLongoPrazo", "");
      handleChange("objetivoLongoPrazoRotulo", "");
      handleChange("aposentadoriaRendaDesejadaMensal", 0);
      setAposentadoriaInput("0");
    }
  };

  const handleObjetivoChange = (e) => {
    const value = e.target.value; // camelCase
    const obj = objetivos.find((o) => o.value === value);
    handleChange("objetivoLongoPrazo", value);
    handleChange("objetivoLongoPrazoRotulo", obj?.label || "");
    // se não for aposentadoria, zera o campo de renda
    if (value !== "garantirBoaAposentadoria") {
      handleChange("aposentadoriaRendaDesejadaMensal", 0);
      setAposentadoriaInput("0");
    }
  };

  const handleAposentadoriaSlider = (e) => {
    const val = clamp(parseInt(e.target.value, 10) || 0, 0, 50000);
    const stepped = roundToStep(val, 500);
    handleChange("aposentadoriaRendaDesejadaMensal", stepped);
    setAposentadoriaInput(String(stepped));
  };

  const handleAposentadoriaInput = (e) => {
    setAposentadoriaInput(e.target.value);
  };

  const normalizeAposentadoriaFromInput = () => {
    const digits = (aposentadoriaInput || "").replace(/\D/g, "");
    const raw = digits === "" ? 0 : parseInt(digits, 10);
    const stepped = roundToStep(raw, 500);
    const val = clamp(stepped, 0, 50000);
    handleChange("aposentadoriaRendaDesejadaMensal", val);
    setAposentadoriaInput(String(val));
  };

  // validação ao estilo das outras seções
  const podeAvancar = () => {
    if (!showQ2) return true;
    if (!respostas.objetivoLongoPrazo) return false;
    if (respostas.objetivoLongoPrazo === "garantirBoaAposentadoria") {
      const v = respostas.aposentadoriaRendaDesejadaMensal;
      return v >= 0 && v <= 50000;
    }
    return true;
  };

  const handleAvancar = () => {
    onComplete(respostas);
  };

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Seção 4: Horizonte &amp; Planos</h2>

      {/* Pergunta 1 — alternativas exclusivas (select) */}
      <div className="space-y-2 mb-6">
        <label className="block font-medium">
          1. Qual o período de tempo mais adequado para a simulação da estratégia?
        </label>
        <select
          className="mt-1 p-2 border rounded w-full"
          value={periodIndex}
          onChange={handlePeriodChange}
        >
          {periodOptions.map((opt, idx) => (
            <option key={opt.months} value={idx}>
              {opt.label}
            </option>
          ))}
        </select>
      </div>

      {/* Pergunta 2 — condicional ao período escolhido */}
      {showQ2 && (
        <div className="space-y-3 mb-6">
          <label className="block font-medium">
            2. Qual das opções abaixo melhor representa seus planos e objetivos financeiros?
          </label>

          <div className="space-y-1">
            {objetivos.map((op) => (
              <label key={op.value} className="inline-flex items-center">
                <input
                  type="radio"
                  className="form-radio"
                  name="objetivoLongoPrazo"
                  value={op.value} // camelCase
                  checked={respostas.objetivoLongoPrazo === op.value}
                  onChange={handleObjetivoChange}
                />
                <span className="ml-2">{op.label}</span>
              </label>
            ))}
          </div>

          {respostas.objetivoLongoPrazo === "garantirBoaAposentadoria" && (
            <div className="mt-3">
              <label className="block font-medium">
                Qual seria, aproximadamente, uma boa renda mensal para sua aposentadoria?
              </label>

              <input
                type="range"
                min={0}
                max={50000}
                step={500}
                value={respostas.aposentadoriaRendaDesejadaMensal}
                onChange={handleAposentadoriaSlider}
                className="w-full"
              />

              <input
                type="text"
                className="mt-2 p-2 border rounded w-full"
                value={aposentadoriaInput}
                onChange={handleAposentadoriaInput}
                onBlur={normalizeAposentadoriaFromInput}
                inputMode="numeric"
                placeholder="Digite um valor inteiro em reais"
              />

              <div className="text-center mt-1">
                {formatBRL(respostas.aposentadoriaRendaDesejadaMensal)}
              </div>
            </div>
          )}
        </div>
      )}

      <div className="mt-6">
        <button
          onClick={handleAvancar}
          disabled={!podeAvancar()}
          className="bg-blue-600 text-white px-4 py-2 rounded disabled:opacity-50"
        >
          Finalizar
        </button>
      </div>
    </div>
  );
};

export default Secao4;
