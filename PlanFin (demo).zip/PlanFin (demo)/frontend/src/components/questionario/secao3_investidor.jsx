// secao3_investidor.jsx — produtos padronizados em camelCase quando "já invisto"
// secao3_investidor.jsx — versão padronizada com camelCase
import React, { useState, useEffect } from "react";

const Secao3 = ({ onComplete }) => {
  const [etapa, setEtapa] = useState(1);
  const [respostas, setRespostas] = useState({});

  const handleChange = (campo, valor) => {
    setRespostas((prev) => ({ ...prev, [campo]: valor }));
  };

  // === MAPEAMENTO DE PRODUTOS (camelCase) ===
  const productKeyMap = {
    // Renda Fixa
    "Tesouro Direto (Selic, Prefixado, IPCA+ etc.)": { check: "temTesouroDireto", value: "valorTesouroDireto" },
    "CDB (Certificado de Depósito Bancário)": { check: "temCDB", value: "valorCDB" },
    "LCI / LCA (Letras de Crédito Imobiliário ou do Agronegócio)": { check: "temLCILCA", value: "valorLCILCA" },
    "Debêntures (comuns ou incentivadas)": { check: "temDeb", value: "valorDeb" },
    "Outro(s) produto(s) de renda fixa": { check: "temOutroRF", value: "valorOutroRF" },

    // Renda Variável
    "Ações (negociadas diretamente na bolsa)": { check: "temAcoes", value: "valorAcoes" },
    "Fundos Imobiliários (FIIs) (fundos que investem em imóveis ou títulos do setor)": { check: "temFII", value: "valorFII" },
    "ETFs (Fundos de Índice negociados em bolsa)": { check: "temETF", value: "valorETF" },
    "BDRs (recibos de ações estrangeiras)": { check: "temBDR", value: "valorBDR" },
    "Criptomoedas (como Bitcoin, Ethereum etc.)": { check: "temCripto", value: "valorCripto" },
    "Outro(s) produto(s) de renda variável (ex.: derivativos etc.)": { check: "temOutroRV", value: "valorOutroRV" },

    // Fundos
    "Fundos de Renda Fixa (investem majoritariamente em títulos de dívida)": { check: "temFundoRF", value: "valorFundoRF" },
    "Fundos Multimercado (mesclam estratégias e ativos diversos)": { check: "temFundoMulti", value: "valorFundoMulti" },
    "Fundos de Ações (alocados em renda variável)": { check: "temFundoAcoes", value: "valorFundoAcoes" },
    "Fundos Cambiais e/ou Internacionais": { check: "temFundoInt", value: "valorFundoInt" },
    "Outro(s) produto(s) de fundos (ex.: fundos de criptoativos etc.)": { check: "temOutroFundo", value: "valorOutroFundo" },

    // Previdência
    "PGBL (Plano Gerador de Benefício Livre — dedutível no IR)": { check: "temPGBL", value: "valorPGBL" },
    "VGBL (Vida Gerador de Benefício Livre — não dedutível)": { check: "temVGBL", value: "valorVGBL" },
    "Previdência Fechada ou Corporativa (ex: fundos de pensão empresariais)": { check: "temPrevCorp", value: "valorPrevCorp" },
    "Outro(s) produto(s) de previdência": { check: "temOutroPrev", value: "valorOutroPrev" },

    // Outros Investimentos
    "COE (Certificado de Operações Estruturadas — combina renda fixa e variável)": { check: "temCOE", value: "valorCOE" },
    "Investimentos por meio de plataformas de financiamento coletivo (startups, imóveis etc.)": { check: "temInvestColet", value: "valorInvestColet" },
    "Investimentos no exterior (via conta internacional ou corretora estrangeira)": { check: "temInvestExt", value: "valorInvestExt" },
    "Outro(s) investimento(s)": { check: "temOutroInvest", value: "valorOutroInvest" },
  };

  // === PERFIL INVESTIDOR ===
  const calcularPerfilInvestidor = () => {
    const p1 = parseInt(respostas.objetivoInvestimento);
    const p2 = parseInt(respostas.reacaoPerda);
    const p3 = parseInt(respostas.prazoInvestimento);
    const p4 = parseInt(respostas.conhecimentoInvestimentos);
    const p5 = parseInt(respostas.toleranciaRisco);
    const p6 = parseInt(respostas.situacaoFinanceira);

    if (![p1, p2, p3, p4, p5, p6].every((n) => !isNaN(n))) return null;
    const total = p1 + p2 + p3 + p4 + p5 + p6;

    if (p6 === 1) return "Conservador";
    if (p2 === 1 && !(p4 === 3 && p5 === 3 && p6 === 3)) {
      if (total >= 14) return "Moderado";
    }
    if (p4 === 1) {
      if (p5 === 3 && p2 === 1) return "Moderado";
      if (p6 === 1) return "Conservador";
    }
    if (total <= 9) return "Conservador";
    if (total <= 13) return "Moderado";
    return "Arrojado";
  };

  useEffect(() => {
    const perfil = calcularPerfilInvestidor();
    if (perfil) handleChange("perfilInvestidor", perfil);
  }, [
    respostas.objetivoInvestimento,
    respostas.reacaoPerda,
    respostas.prazoInvestimento,
    respostas.conhecimentoInvestimentos,
    respostas.toleranciaRisco,
    respostas.situacaoFinanceira,
  ]);

  const perfilAtual = calcularPerfilInvestidor();

  const podeAvancar = () => {
    if (etapa === 1) return respostas.historicoInvestimento !== undefined;
    if (etapa === 2) return true;
    if (etapa === 3) return respostas.perfilInvestidor !== undefined;
    if (etapa === 4) {
      return (
        respostas.objetivoInvestimento &&
        respostas.reacaoPerda &&
        respostas.prazoInvestimento &&
        respostas.conhecimentoInvestimentos &&
        respostas.toleranciaRisco &&
        respostas.situacaoFinanceira
      );
    }
    return true;
  };

  const handleAvancar = () => {
    if (etapa === 1 && respostas.historicoInvestimento === "Sim, já invisto") setEtapa(2);
    else if (etapa === 1 && respostas.historicoInvestimento === "Sim, já investi, mas não invisto no momento") setEtapa(3);
    else if (etapa === 1 && respostas.historicoInvestimento === "Não, nunca investi") setEtapa(4);
    else if (etapa === 2) setEtapa(3);
    else if (etapa === 3 && respostas.perfilInvestidor === "Não sei") setEtapa(4);
    else if (etapa === 3 || etapa === 4) onComplete(respostas);
  };

  const formatarParaReal = (valor, limite = 500000) => {
    if (!valor) return "R$0";
    const num = Number(valor);
    if (Number.isNaN(num)) return "R$0";
    if (num >= limite) return `R$${limite.toLocaleString("pt-BR")} ou mais`;
    return num.toLocaleString("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 0 });
  };

  // === CATALOGO DE PRODUTOS ===
  const gruposProdutos = [
    {
      titulo: "**Renda Fixa**",
      itens: [
        "Tesouro Direto (Selic, Prefixado, IPCA+ etc.)",
        "CDB (Certificado de Depósito Bancário)",
        "LCI / LCA (Letras de Crédito Imobiliário ou do Agronegócio)",
        "Debêntures (comuns ou incentivadas)",
        "Outro(s) produto(s) de renda fixa",
      ],
    },
    {
      titulo: "**Renda Variável**",
      itens: [
        "Ações (negociadas diretamente na bolsa)",
        "Fundos Imobiliários (FIIs) (fundos que investem em imóveis ou títulos do setor)",
        "ETFs (Fundos de Índice negociados em bolsa)",
        "BDRs (recibos de ações estrangeiras)",
        "Criptomoedas (como Bitcoin, Ethereum etc.)",
        "Outro(s) produto(s) de renda variável (ex.: derivativos etc.)",
      ],
    },
    {
      titulo: "**Fundos de Investimento**",
      itens: [
        "Fundos de Renda Fixa (investem majoritariamente em títulos de dívida)",
        "Fundos Multimercado (mesclam estratégias e ativos diversos)",
        "Fundos de Ações (alocados em renda variável)",
        "Fundos Cambiais e/ou Internacionais",
        "Outro(s) produto(s) de fundos (ex.: fundos de criptoativos etc.)",
      ],
    },
    {
      titulo: "**Previdência Privada**",
      itens: [
        "PGBL (Plano Gerador de Benefício Livre — dedutível no IR)",
        "VGBL (Vida Gerador de Benefício Livre — não dedutível)",
        "Previdência Fechada ou Corporativa (ex: fundos de pensão empresariais)",
        "Outro(s) produto(s) de previdência",
      ],
    },
    {
      titulo: "**Outros Investimentos**",
      itens: [
        "COE (Certificado de Operações Estruturadas — combina renda fixa e variável)",
        "Investimentos por meio de plataformas de financiamento coletivo (startups, imóveis etc.)",
        "Investimentos no exterior (via conta internacional ou corretora estrangeira)",
        "Outro(s) investimento(s)",
      ],
    },
  ];

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Seção 3: Perfil de Investidor e Investimentos</h2>

      {/* Etapa 1 */}
      {etapa === 1 && (
        <div className="space-y-4">
          <label className="block font-medium">14. Você já investe ou já investiu seu dinheiro em algum produto financeiro?</label>
          <div className="mt-2 space-y-1">
            {["Sim, já invisto", "Sim, já investi, mas não invisto no momento", "Não, nunca investi"].map((opcao) => (
              <label key={opcao} className="inline-flex items-center">
                <input
                  type="radio"
                  className="form-radio"
                  name="historicoInvestimento"
                  value={opcao}
                  checked={respostas.historicoInvestimento === opcao}
                  onChange={(e) => handleChange("historicoInvestimento", e.target.value)}
                />
                <span className="ml-2">{opcao}</span>
              </label>
            ))}
          </div>
        </div>
      )}

      {/* Etapa 2 */}
      {etapa === 2 && respostas.historicoInvestimento === "Sim, já invisto" && (
        <div className="space-y-6">
          <label className="block font-medium text-lg">
            15. Quais dos produtos abaixo você possui atualmente em sua carteira de investimentos? E qual o valor aproximado?
          </label>
          {gruposProdutos.map((grupo) => (
            <div key={grupo.titulo} className="space-y-4">
              <h3 className="font-bold" dangerouslySetInnerHTML={{ __html: grupo.titulo }} />
              {grupo.itens.map((item) => {
                const keys = productKeyMap[item] || { check: `${item}_check`, value: `${item}_valor` };
                const checked = !!respostas[keys.check];
                return (
                  <div key={item} className="mt-2">
                    <label className="inline-flex items-center">
                      <input
                        type="checkbox"
                        className="form-checkbox"
                        checked={checked}
                        onChange={(e) => handleChange(keys.check, e.target.checked)}
                      />
                      <span className="ml-2 italic">{item}</span>
                    </label>
                    {checked && (
                      <div className="mt-1">
                        <input
                          type="range"
                          min="100"
                          max="500000"
                          step="100"
                          value={respostas[keys.value] || 100}
                          onChange={(e) => handleChange(keys.value, Math.min(Number(e.target.value), 500000))}
                          className="w-full"
                        />
                        <input
                          type="number"
                          placeholder="Digite o valor em R$"
                          className="mt-1 p-2 border rounded w-full"
                          value={respostas[keys.value] || ""}
                          onChange={(e) => handleChange(keys.value, (e.target.value || "").replace(/\D/g, ""))}
                        />
                        <div className="text-center">{formatarParaReal(respostas[keys.value], 500000)}</div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      )}

      {/* Etapa 3 */}
      {etapa === 3 && ["Sim, já invisto", "Sim, já investi, mas não invisto no momento"].includes(respostas.historicoInvestimento) && (
        <div className="space-y-4">
          <label className="block font-medium">16. Como você se classificaria como investidor?</label>
          <p className="text-sm text-gray-600">Caso não saiba, selecione "Não sei".</p>
          <div className="mt-2 space-y-1">
            {["Conservador", "Moderado", "Arrojado", "Não sei"].map((opcao) => (
              <label key={opcao} className="inline-flex items-center">
                <input
                  type="radio"
                  className="form-radio"
                  name="perfilInvestidor"
                  value={opcao}
                  checked={respostas.perfilInvestidor === opcao}
                  onChange={(e) => handleChange("perfilInvestidor", e.target.value)}
                />
                <span className="ml-2">{opcao}</span>
              </label>
            ))}
          </div>
        </div>
      )}

      {etapa === 4 && (
        <div className="space-y-6">
          {perfilAtual && (
            <div className="p-4 bg-gray-100 rounded border border-gray-300 mb-4 text-center">
              <strong>Seu perfil é:</strong>{" "}
              <span className="font-bold text-blue-600">{perfilAtual}</span>
            </div>
          )}

          <h3 className="text-lg font-semibold">17. Questionário de Suitability</h3>

          {/* Pergunta 1 */}
          <div>
            <label className="block font-medium">1. Qual é o seu principal objetivo ao investir atualmente?</label>
            {[
              "Preservar meu capital e ter segurança.",
              "Buscar equilíbrio entre segurança e rentabilidade.",
              "Obter a maior rentabilidade possível, mesmo assumindo riscos.",
            ].map((opcao, idx) => (
              <div key={opcao}>
                <label className="inline-flex items-center">
                  <input
                    type="radio"
                    className="form-radio"
                    name="objetivoInvestimento"
                    value={(idx + 1).toString()}
                    checked={respostas.objetivoInvestimento === (idx + 1).toString()}
                    onChange={(e) => handleChange("objetivoInvestimento", e.target.value)}
                  />
                  <span className="ml-2">{opcao}</span>
                </label>
              </div>
            ))}
          </div>

          {/* Pergunta 2 */}
          <div>
            <label className="block font-medium">2. Como você reagiria se seus investimentos sofressem uma perda de 10% em um mês?</label>
            {[
              "Venderia tudo imediatamente para evitar maiores perdas.",
              "Manteria os investimentos esperando uma recuperação.",
              "Aproveitaria para comprar mais, acreditando no longo prazo.",
            ].map((opcao, idx) => (
              <div key={opcao}>
                <label className="inline-flex items-center">
                  <input
                    type="radio"
                    className="form-radio"
                    name="reacaoPerda"
                    value={(idx + 1).toString()}
                    checked={respostas.reacaoPerda === (idx + 1).toString()}
                    onChange={(e) => handleChange("reacaoPerda", e.target.value)}
                  />
                  <span className="ml-2">{opcao}</span>
                </label>
              </div>
            ))}
          </div>

          {/* Pergunta 3 */}
          <div>
            <label className="block font-medium">3. Por quanto tempo você pretende deixar seu dinheiro investido?</label>
            {["Menos de 1 ano.", "Entre 1 e 5 anos.", "Mais de 5 anos."].map((opcao, idx) => (
              <div key={opcao}>
                <label className="inline-flex items-center">
                  <input
                    type="radio"
                    className="form-radio"
                    name="prazoInvestimento"
                    value={(idx + 1).toString()}
                    checked={respostas.prazoInvestimento === (idx + 1).toString()}
                    onChange={(e) => handleChange("prazoInvestimento", e.target.value)}
                  />
                  <span className="ml-2">{opcao}</span>
                </label>
              </div>
            ))}
          </div>

          {/* Pergunta 4 */}
          <div>
            <label className="block font-medium">4. Quanto conhecimento você tem sobre investimentos?</label>
            {[
              "Pouco ou nenhum — estou começando agora.",
              "Razoável — conheço os principais produtos.",
              "Avançado — entendo bem os riscos e estratégias.",
            ].map((opcao, idx) => (
              <div key={opcao}>
                <label className="inline-flex items-center">
                  <input
                    type="radio"
                    className="form-radio"
                    name="conhecimentoInvestimentos"
                    value={(idx + 1).toString()}
                    checked={respostas.conhecimentoInvestimentos === (idx + 1).toString()}
                    onChange={(e) => handleChange("conhecimentoInvestimentos", e.target.value)}
                  />
                  <span className="ml-2">{opcao}</span>
                </label>
              </div>
            ))}
          </div>

          {/* Pergunta 5 */}
          <div>
            <label className="block font-medium">5. Qual dessas opções melhor representa sua tolerância ao risco?</label>
            {[
              "Prefiro ganhos previsíveis, mesmo que menores.",
              "Aceito certa oscilação para buscar retornos melhores.",
              "Estou disposto a correr riscos altos por ganhos maiores.",
            ].map((opcao, idx) => (
              <div key={opcao}>
                <label className="inline-flex items-center">
                  <input
                    type="radio"
                    className="form-radio"
                    name="toleranciaRisco"
                    value={(idx + 1).toString()}
                    checked={respostas.toleranciaRisco === (idx + 1).toString()}
                    onChange={(e) => handleChange("toleranciaRisco", e.target.value)}
                  />
                  <span className="ml-2">{opcao}</span>
                </label>
              </div>
            ))}
          </div>

          {/* Pergunta 6 */}
          <div>
            <label className="block font-medium">6. Qual a sua situação financeira atual?</label>
            {[
              "Tenho pouca margem para perdas ou imprevistos.",
              "Tenho alguma reserva e estabilidade.",
              "Tenho alta estabilidade e posso correr riscos sem comprometer meu padrão de vida.",
            ].map((opcao, idx) => (
              <div key={opcao}>
                <label className="inline-flex items-center">
                  <input
                    type="radio"
                    className="form-radio"
                    name="situacaoFinanceira"
                    value={(idx + 1).toString()}
                    checked={respostas.situacaoFinanceira === (idx + 1).toString()}
                    onChange={(e) => handleChange("situacaoFinanceira", e.target.value)}
                  />
                  <span className="ml-2">{opcao}</span>
                </label>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="mt-6">
        <button
          onClick={handleAvancar}
          disabled={!podeAvancar()}
          className="bg-blue-600 text-white px-4 py-2 rounded disabled:opacity-50"
        >
          {/* [MOD 1] Sem etapa 5 */}
          {etapa < 4 ? "Continuar" : "Próxima seção"}
        </button>
      </div>
    </div>
  );
};

export default Secao3;
